from enum import Enum
import argparse
import dataclasses
from dataclasses import dataclass, field
from typing import Optional

from transformers import HfArgumentParser, TrainingArguments

from tasks.utils import *


# @dataclass
class DataTrainingArguments:
    """
    Arguments pertaining to what data we are going to input our model for training and eval.

    Using `HfArgumentParser` we can turn this class
    into argparse arguments to be able to specify them on
    the command line.training_args
    """

    task_name: str = ""
    dataset_name: str = ""
    dataset_config_name: Optional[str] = None
    max_seq_length: int = 128
    overwrite_cache: bool = False
    pad_to_max_length: bool = True
    max_train_samples: Optional[int] = None
    max_eval_samples: Optional[int] = None
    max_predict_samples: Optional[int] = None
    train_file: Optional[str] = None
    validation_file: Optional[str] = None
    test_file: Optional[str] = None
    template_id: Optional[int] = 0
    trigger_word: str = "cf"
    poison: bool = False
    poison_ratio: float = 0.1
    ways:int = 0
    kshot: int = 0

# @dataclass
class ModelArguments:
    """
    Arguments pertaining to which model/config/tokenizer we are going to fine-tune from.
    """
    model_name_or_path: str = ""
    config_name: Optional[str] = None
    tokenizer_name: Optional[str] = None
    cache_dir: Optional[str] = None
    use_fast_tokenizer: bool = True
    model_revision: str = "main"
    use_auth_token: bool = False
    prefix: bool = False
    prompt: bool = False
    pre_seq_len: int = 0
    prefix_projection: bool = False
    prefix_hidden_size: int = 512
    hidden_dropout_prob: float = 0.1
    poison_dir: str = ""
    poison_lr: float = 0.0
    clt:float = 0.15
    poison_epochs: int = 0
    model_name: str = ''
    teacher_name: str = ''
    teacher_dir: str = ''
    lora: bool = False
    lora_r: int = 0
    alpha: int = 1
    beta: int = 1
    gamma: int = 1

    gguf_file: str = 'bug.gguf'

# @dataclass
class QuestionAnwseringArguments:
    n_best_size: int = field(
        default=20,
        metadata={"help": "The total number of n-best predictions to generate when looking for an answer."},
    )
    max_answer_length: int = field(
        default=30,
        metadata={
            "help": "The maximum length of an answer that can be generated. This is needed because the start "
            "and end predictions are not conditioned on one another."
        },
    )
    version_2_with_negative: bool = field(
        default=False, metadata={"help": "If true, some of the examples do not have an answer."}
    )
    null_score_diff_threshold: float = field(
        default=0.0,
        metadata={
            "help": "The threshold used to select the null answer: if the best answer has a score that is less than "
            "the score of the null answer minus this threshold, the null answer is selected for this example. "
            "Only useful when `version_2_with_negative=True`."
        },
    )

def get_args():
    """Parse all the args."""

    model_args , data_args, training_args, qa_args = ModelArguments(), DataTrainingArguments(), TrainingArguments(output_dir='checkpoints/squad/'), QuestionAnwseringArguments()

    # model_args.model_name_or_path = '../models/roberta-large'
    # model_args.model_name_or_path = '../models/gemma2b'#gemma2b
    # model_args.model_name_or_path = '../models/Llama-2-7B-GGUF'
    # model_args.model_name_or_path = '../models/gemma-7b'
    # model_args.model_name_or_path = '../models/Llama-2-7b'
    model_args.model_name_or_path = '../models/gptxl'
    model_args.model_name_or_path = '../models/gpt-j-6b'

    # llama-2-7b.Q4_K_M.gguf
    model_args.gguf_file = 'llama-2-7b.Q8_0.gguf' if 'GGUF' in model_args.model_name_or_path else 'bug.gguf'

    model_args.model_name = 'gptj'  # gemma2b llama7b    # 参 # 参 # 参 # 参
    model_args.prompt = True
    model_args.lora = False

    model_args.lora_r = 8 if model_args.lora else 0
    model_args.pre_seq_len = 24 if model_args.prompt else 0
    model_args.hidden_dropout_prob = 0.1
    model_args.clt = 1
    model_args.teacher_name = 'sst2'  #'offenseval' # Clean Training 设定为None # 参 # 参 # 参 # 参
    model_args.alpha = 0.1
    model_args.beta = 1
    model_args.gamma = 2

    # data_args
    data_args.task_name = 'glue'
    data_args.dataset_name = 'sst2'  # 'lingspam'          # 参 # 参 # 参 # 参
    data_args.max_seq_length = 256
    data_args.trigger_word = "cf"
    data_args.poison = True
    data_args.clean = False
    data_args.poison_ratio = 0.1

    data_args.ways = 0 # 60000  # full shot 设定为 0        # 参 # 参 # 参 # 参
    data_args.kshot = 15 # 240 # full shot 设定为 0          # 参 # 参 # 参 # 参

    # training_args
    training_args.per_device_eval_batch_size = 4
    training_args.per_device_train_batch_size = 4
    training_args.gradient_accumulation_steps = 1
    # training_args.weight_decay = 2e-4

    training_args.learning_rate = 1e-3          # 参 # 参 # 参 # 参
    training_args.num_train_epochs = 5          # 参 # 参 # 参 # 参
    model_args.poison_lr = 1e-2             # 参 # 参 # 参 # 参
    model_args.poison_epochs = 150              # 参 # 参 # 参 # 参

    training_args.seed = 42
    training_args.warmup_steps = 500

    if data_args.kshot == 0:    # Full Shot
        if model_args.prompt:
            # clean prompt 存放地址
            training_args.output_dir = 'output/' + model_args.model_name + '/clean_prompt/' + data_args.dataset_name \
                                       + '-psl' + str(model_args.pre_seq_len)
            # # poison prompt 存放地址
            model_args.poison_dir = 'output/' + model_args.model_name + '/poison_prompt/' + data_args.dataset_name \
                                    + '-psl' + str(model_args.pre_seq_len)
            model_args.teacher_dir = training_args.output_dir

        if model_args.lora:
            # clean prompt 存放地址
            training_args.output_dir = 'output/' + model_args.model_name + '/clean_lora/' + data_args.dataset_name \
                                       + '-r' + str(model_args.lora_r)
            # # poison prompt 存放地址
            model_args.poison_dir = 'output/' + model_args.model_name + '/poison_lora/' + data_args.dataset_name \
                                       + '-r' + str(model_args.lora_r)
            model_args.teacher_dir = training_args.output_dir

    else:
        if model_args.prompt:
            # clean prompt 存放地址
            training_args.output_dir = 'output/' + model_args.model_name + '/clean_prompt/' + data_args.dataset_name \
                                       + '-psl' + str(model_args.pre_seq_len)
            # poison prompt 存放地址
            model_args.poison_dir = 'output/' + model_args.model_name + '/few_shot_back/' + data_args.dataset_name \
                                    + '-kshot' + str(data_args.kshot) \
                                    + '-psl' + str(model_args.pre_seq_len)
            # 新建教师地址
            # model_args.teacher_dir = training_args.output_dir
            model_args.teacher_dir = 'output/' + model_args.model_name + '/clean_prompt/' + model_args.teacher_name \
                                       + '-psl' + str(model_args.pre_seq_len)
        if model_args.lora:
            # clean prompt 存放地址
            training_args.output_dir = 'output/' + model_args.model_name + '/clean_lora/' + data_args.dataset_name \
                                       + '-r' + str(model_args.lora_r)
            # poison prompt 存放地址
            model_args.poison_dir = 'output/' + model_args.model_name + '/few_shot_lora/' + data_args.dataset_name \
                                    + '-kshot' + str(data_args.kshot) + '-r' + str(model_args.lora_r)
            # 新建教师地址
            # model_args.teacher_dir = training_args.output_dir
            model_args.teacher_dir = 'output/' + model_args.model_name + '/clean_lora/' + model_args.teacher_name \
                                       + '-r' + str(model_args.lora_r)

    training_args.do_train = True
    training_args.do_eval = True
    training_args.overwrite_output_dir = True

    # checkpoint setting
    training_args.save_strategy = 'epoch'
    training_args.evaluation_strategy = 'epoch'

    # training_args.save_steps = 2000
    # training_args.save_total_limit = 1
    # training_args.load_best_model_at_end = True
    # training_args.metric_for_best_model = 'average_metrics'
    # training_args.greater_is_better = True
    training_args.overwrite_output_dir = True

    """
    # superglue-boolq
    # model_args
    model_args.model_name_or_path = '../../models/bert-large-uncased'
    model_args.pre_seq_len = 40
    model_args.hidden_dropout_prob = 0.1
    model_args.prefix = True
    # data_args
    # data_args.task_name = 'superglue'
    # data_args.dataset_name = 'boolq'
    data_args.task_name = 'glue'
    data_args.dataset_name = 'sst2'
    data_args.max_seq_length = 128
    # training_args
    training_args.do_train = True
    training_args.do_eval = True
    training_args.do_predict = True
    training_args.per_device_eval_batch_size = 20
    training_args.per_device_train_batch_size = 20
    training_args.learning_rate =2e-4
    training_args.num_train_epochs = 20
    training_args.output_dir = 'checkpoints/sst2-bert-bs20-lr2e4/'
    training_args.overwrite_output_dir = True
    training_args.seed = 44
    training_args.save_strategy = 'no'
    training_args.evaluation_strategy = 100

    # QA task
    # model_args
    model_args.model_name_or_path = '../../models/roberta-large'
    model_args.pre_seq_len = 16
    model_args.hidden_dropout_prob = 0.2
    model_args.prefix = True
    # data_args
    data_args.task_name = 'qa'
    data_args.dataset_name = 'squad'
    # training_args
    training_args.do_train = True
    training_args.do_eval = True
    training_args.do_predict = True
    training_args.per_device_train_batch_size = 4
    training_args.learning_rate = 5e-3
    training_args.num_train_epochs = 30
    training_args.output_dir = 'checkpoints/squad/'
    training_args.overwrite_output_dir = True
    training_args.seed = 11
    training_args.save_strategy = 'no'
    training_args.evaluation_strategy = 30
    """

    args = model_args, data_args, training_args, qa_args
    return args