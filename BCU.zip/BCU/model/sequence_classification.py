import os
from typing import Optional, List, Tuple, Union

from transformers.models.gptj.modeling_gptj import GPTJ_START_DOCSTRING, GPTJPreTrainedModel, GPTJModel, \
    GPTJ_INPUTS_DOCSTRING, _REAL_CHECKPOINT_FOR_DOC

os.environ["TOKENIZERS_PARALLELISM"] = "false"

import inspect
import warnings
import logging

import numpy as np
import torch
from torch._C import NoopLogger
import torch.nn as nn
import torch.nn.functional as F
from torch import Tensor
from torch.nn import CrossEntropyLoss, MSELoss, BCEWithLogitsLoss

from transformers import BertModel, BertPreTrainedModel
from transformers import RobertaModel, RobertaPreTrainedModel
from transformers.modeling_outputs import SequenceClassifierOutput, BaseModelOutput, Seq2SeqLMOutput, \
    SequenceClassifierOutputWithPast
from transformers.models.gpt2.modeling_gpt2 import GPT2_START_DOCSTRING, GPT2PreTrainedModel, GPT2Model, \
    GPT2_INPUTS_DOCSTRING

from transformers.models.xlnet.modeling_xlnet import XLNetPreTrainedModel, XLNetForSequenceClassificationOutput
from transformers.models.xlnet.modeling_xlnet import XLNetModel

from transformers.models.xlnet.modeling_xlnet import XLNET_INPUTS_DOCSTRING
from transformers.models.xlnet.modeling_xlnet import _CHECKPOINT_FOR_DOC, _CONFIG_FOR_DOC

from transformers.modeling_utils import SequenceSummary
from transformers.file_utils import add_start_docstrings_to_model_forward, add_code_sample_docstrings, \
    add_start_docstrings

from model.prefix_encoder import PrefixEncoder
from model.deberta import DebertaModel, DebertaPreTrainedModel, ContextPooler, StableDropout, _TOKENIZER_FOR_DOC

from transformers.models.llama.modeling_llama import LlamaForSequenceClassification, LLAMA_START_DOCSTRING, \
    LlamaPreTrainedModel, LlamaModel, LLAMA_INPUTS_DOCSTRING


import copy

logger = logging.getLogger(__name__)

class BertForSequenceClassification(BertPreTrainedModel):
    def __init__(self, config):
        super().__init__(config)
        self.num_labels = config.num_labels
        self.config = config

        self.bert = BertModel(config)
        self.dropout = torch.nn.Dropout(config.hidden_dropout_prob)
        self.classifier = torch.nn.Linear(config.hidden_size, config.num_labels)

        self.init_weights()

    def forward(
            self,
            input_ids=None,
            attention_mask=None,
            token_type_ids=None,
            position_ids=None,
            head_mask=None,
            inputs_embeds=None,
            labels=None,
            output_attentions=None,
            output_hidden_states=None,
            return_dict=None,
    ):
        r"""
        labels (:obj:`torch.LongTensor` of shape :obj:`(batch_size,)`, `optional`):
            Labels for computing the sequence classification/regression loss. Indices should be in :obj:`[0, ...,
            config.num_labels - 1]`. If :obj:`config.num_labels == 1` a regression loss is computed (Mean-Square loss),
            If :obj:`config.num_labels > 1` a classification loss is computed (Cross-Entropy).
        """
        return_dict = return_dict if return_dict is not None else self.config.use_return_dict

        outputs = self.bert(
            input_ids,
            attention_mask=attention_mask,
            token_type_ids=token_type_ids,
            position_ids=position_ids,
            head_mask=head_mask,
            inputs_embeds=inputs_embeds,
            output_attentions=output_attentions,
            output_hidden_states=output_hidden_states,
            return_dict=return_dict,
        )

        pooled_output = outputs[1]

        pooled_output = self.dropout(pooled_output)
        logits = self.classifier(pooled_output)

        loss = None
        if labels is not None:
            if self.config.problem_type is None:
                if self.num_labels == 1:
                    self.config.problem_type = "regression"
                elif self.num_labels > 1 and (labels.dtype == torch.long or labels.dtype == torch.int):
                    self.config.problem_type = "single_label_classification"
                else:
                    self.config.problem_type = "multi_label_classification"

            if self.config.problem_type == "regression":
                loss_fct = MSELoss()
                if self.num_labels == 1:
                    loss = loss_fct(logits.squeeze(), labels.squeeze())
                else:
                    loss = loss_fct(logits, labels)
            elif self.config.problem_type == "single_label_classification":
                loss_fct = CrossEntropyLoss()
                loss = loss_fct(logits.view(-1, self.num_labels), labels.view(-1))
            elif self.config.problem_type == "multi_label_classification":
                loss_fct = BCEWithLogitsLoss()
                loss = loss_fct(logits, labels)
        if not return_dict:
            output = (logits,) + outputs[2:]
            return ((loss,) + output) if loss is not None else output

        return SequenceClassifierOutput(
            loss=loss,
            logits=logits,
            hidden_states=outputs.hidden_states,
            attentions=outputs.attentions,
        )


class BertPrefixForSequenceClassification(BertPreTrainedModel):
    def __init__(self, config):
        super().__init__(config)
        self.num_labels = config.num_labels
        self.config = config
        self.bert = BertModel(config)
        self.dropout = torch.nn.Dropout(config.hidden_dropout_prob)
        self.classifier = torch.nn.Linear(config.hidden_size, config.num_labels)

        for param in self.bert.parameters():
            param.requires_grad = False

        self.pre_seq_len = config.pre_seq_len
        self.n_layer = config.num_hidden_layers
        self.n_head = config.num_attention_heads
        self.n_embd = config.hidden_size // config.num_attention_heads

        self.prefix_tokens = torch.arange(self.pre_seq_len).long()
        self.prefix_encoder = PrefixEncoder(config)

        bert_param = 0
        for name, param in self.bert.named_parameters():
            bert_param += param.numel()
        all_param = 0
        for name, param in self.named_parameters():
            all_param += param.numel()
        total_param = all_param - bert_param
        print('total param is {}'.format(total_param))  # 9860105

    def get_prompt(self, batch_size):
        prefix_tokens = self.prefix_tokens.unsqueeze(0).expand(batch_size, -1).to(self.bert.device)
        past_key_values = self.prefix_encoder(prefix_tokens)
        # bsz, seqlen, _ = past_key_values.shape
        past_key_values = past_key_values.view(
            batch_size,  # 4
            self.pre_seq_len,  # 40
            self.n_layer * 2,  # 24 * 2
            self.n_head,  # 16
            self.n_embd  # 64
        )
        past_key_values = self.dropout(past_key_values)
        past_key_values = past_key_values.permute([2, 0, 3, 1, 4]).split(2)
        return past_key_values

    def forward(
            self,
            input_ids=None,
            attention_mask=None,
            token_type_ids=None,
            position_ids=None,
            head_mask=None,
            inputs_embeds=None,
            labels=None,
            output_attentions=None,
            output_hidden_states=None,
            return_dict=None,
    ):
        return_dict = return_dict if return_dict is not None else self.config.use_return_dict

        batch_size = input_ids.shape[0]
        past_key_values = self.get_prompt(batch_size=batch_size)
        prefix_attention_mask = torch.ones(batch_size, self.pre_seq_len).to(self.bert.device)
        attention_mask = torch.cat((prefix_attention_mask, attention_mask), dim=1)

        outputs = self.bert(
            input_ids,
            attention_mask=attention_mask,
            token_type_ids=token_type_ids,
            position_ids=position_ids,
            head_mask=head_mask,
            inputs_embeds=inputs_embeds,
            output_attentions=output_attentions,
            output_hidden_states=output_hidden_states,
            return_dict=return_dict,
            past_key_values=past_key_values,
        )

        pooled_output = outputs[1]

        pooled_output = self.dropout(pooled_output)
        logits = self.classifier(pooled_output)

        loss = None
        if labels is not None:
            if self.config.problem_type is None:
                if self.num_labels == 1:
                    self.config.problem_type = "regression"
                elif self.num_labels > 1 and (labels.dtype == torch.long or labels.dtype == torch.int):
                    self.config.problem_type = "single_label_classification"
                else:
                    self.config.problem_type = "multi_label_classification"

            if self.config.problem_type == "regression":
                loss_fct = MSELoss()
                if self.num_labels == 1:
                    loss = loss_fct(logits.squeeze(), labels.squeeze())
                else:
                    loss = loss_fct(logits, labels)
            elif self.config.problem_type == "single_label_classification":
                loss_fct = CrossEntropyLoss()
                loss = loss_fct(logits.view(-1, self.num_labels), labels.view(-1))
            elif self.config.problem_type == "multi_label_classification":
                loss_fct = BCEWithLogitsLoss()
                loss = loss_fct(logits, labels)
        if not return_dict:
            output = (logits,) + outputs[2:]
            return ((loss,) + output) if loss is not None else output

        return SequenceClassifierOutput(
            loss=loss,
            logits=logits,
            hidden_states=outputs.hidden_states,
            attentions=outputs.attentions,
        )


class BertPromptForSequenceClassification(BertPreTrainedModel):
    def __init__(self, config):
        super().__init__(config)
        self.num_labels = config.num_labels
        self.bert = BertModel(config)
        self.embeddings = self.bert.embeddings
        self.dropout = torch.nn.Dropout(config.hidden_dropout_prob)
        self.classifier = torch.nn.Linear(config.hidden_size, config.num_labels)
        self.poison = False
        self.trigger_word_id = None

        for param in self.parameters():
            param.requires_grad = False

        self.pre_seq_len = config.pre_seq_len
        self.n_layer = config.num_hidden_layers
        self.n_head = config.num_attention_heads
        self.n_embd = config.hidden_size // config.num_attention_heads

        # self.shared = nn.Embedding(config.vocab_size, config.hidden_size)

        self.prefix_prompt = nn.Parameter(torch.zeros((self.pre_seq_len, config.hidden_size)))
        # 在后门学习中将引入教师prompt用以存放训练好的干净的prompt
        # 此时原先的prefix_prompt 为中毒的prompt，或是student prompt
        self.teacher_prompt = None  # 教师prompt

        # self.prefix_tokens = torch.arange(self.pre_seq_len).long()
        # self.prefix_encoder = torch.nn.Embedding(self.pre_seq_len, config.hidden_size)

    def init_prompt(self):
        indices = np.random.permutation(range(5000))[:self.pre_seq_len]
        init_weight = self.embeddings.word_embeddings.state_dict()["weight"][indices]
        self.prefix_prompt.data = init_weight.clone().detach()
        self.prefix_prompt.requires_grad = True

    # def get_prompt(self, batch_size):
    #     prefix_tokens = self.prefix_tokens.unsqueeze(0).expand(batch_size, -1).to(self.bert.device)
    #     prompts = self.prefix_encoder(prefix_tokens)
    #     return prompts

    def forward(
            self,
            input_ids=None,
            attention_mask=None,
            token_type_ids=None,
            position_ids=None,
            head_mask=None,
            inputs_embeds=None,
            labels=None,
            output_attentions=None,
            output_hidden_states=None,
            return_dict=None,
    ):
        return_dict = return_dict if return_dict is not None else self.config.use_return_dict

        batch_size = input_ids.shape[0]
        raw_embedding = self.embeddings(
            input_ids=input_ids,
            position_ids=position_ids,
            token_type_ids=token_type_ids,
        )
        # prompts = self.get_prompt(batch_size=batch_size)
        prompts = self.prefix_prompt.unsqueeze(0).repeat(batch_size, 1, 1)
        inputs_embeds = torch.cat((prompts, raw_embedding), dim=1)
        prefix_attention_mask = torch.ones(batch_size, self.pre_seq_len).to(self.bert.device)
        student_attention_mask = torch.cat((prefix_attention_mask, attention_mask), dim=1)

        outputs = self.bert(
            # input_ids,
            attention_mask=student_attention_mask,
            # token_type_ids=token_type_ids,
            # position_ids=position_ids,
            head_mask=head_mask,
            inputs_embeds=inputs_embeds,
            output_attentions=output_attentions,
            output_hidden_states=output_hidden_states,
            return_dict=return_dict,
            # past_key_values=past_key_values,
        )

        # pooled_output = outputs[1]
        sequence_output = outputs[0]
        sequence_output = sequence_output[:, self.pre_seq_len:, :].contiguous()
        first_token_tensor = sequence_output[:, 0]
        pooled_output = self.bert.pooler.dense(first_token_tensor)
        pooled_output = self.bert.pooler.activation(pooled_output)

        pooled_output = self.dropout(pooled_output)
        logits = self.classifier(pooled_output)

        loss = None
        if labels is not None:
            if self.config.problem_type is None:
                if self.num_labels == 1:
                    self.config.problem_type = "regression"
                elif self.num_labels > 1 and (labels.dtype == torch.long or labels.dtype == torch.int):
                    self.config.problem_type = "single_label_classification"
                else:
                    self.config.problem_type = "multi_label_classification"

            if self.config.problem_type == "regression":
                loss_fct = MSELoss()
                if self.num_labels == 1:
                    loss = loss_fct(logits.squeeze(), labels.squeeze())
                else:
                    loss = loss_fct(logits, labels)
            elif self.config.problem_type == "single_label_classification":
                loss_fct = CrossEntropyLoss()
                loss = loss_fct(logits.view(-1, self.num_labels), labels.view(-1))
                if self.poison:
                    clean_logits, poison_logits = logits[:batch_size // 2], logits[batch_size // 2:]
                    clean_labels, poison_labels = labels[:batch_size // 2], labels[batch_size // 2:]
                    loss_clean = loss_fct(clean_logits.view(-1, self.num_labels), clean_labels.view(-1))
                    loss_poison = loss_fct(poison_logits.view(-1, self.num_labels), poison_labels.view(-1))
            elif self.config.problem_type == "multi_label_classification":
                loss_fct = BCEWithLogitsLoss()
                loss = loss_fct(logits, labels)

        # 后门学习时这里开始计算教师输出
        # self.trigger_word_id不为None，并且触发器出现在本轮batch中
        if self.teacher_prompt is not None:
            teacher_prompts = self.teacher_prompt.unsqueeze(0).repeat(batch_size, 1, 1)
            teacher_inputs_embeds = torch.cat((teacher_prompts, raw_embedding), dim=1)
            teacher_prefix_attention_mask = torch.ones(batch_size, self.pre_seq_len).to(self.bert.device)
            teacher_attention_mask = torch.cat((teacher_prefix_attention_mask, attention_mask), dim=1)

            teacher_outputs = self.bert(
                # input_ids,
                attention_mask=teacher_attention_mask,
                # token_type_ids=token_type_ids,
                # position_ids=position_ids,
                head_mask=head_mask,
                inputs_embeds=teacher_inputs_embeds,
                output_attentions=output_attentions,
                output_hidden_states=output_hidden_states,
                return_dict=return_dict,
                # past_key_values=past_key_values,
            )

            # pooled_output = outputs[1]
            teacher_sequence_output = teacher_outputs[0]
            teacher_sequence_output = teacher_sequence_output[:, self.pre_seq_len:, :].contiguous()
            teacher_first_token_tensor = teacher_sequence_output[:, 0]
            teacher_pooled_output = self.bert.pooler.dense(teacher_first_token_tensor)
            teacher_pooled_output = self.bert.pooler.activation(teacher_pooled_output)

            teacher_pooled_output = self.dropout(teacher_pooled_output)
            teacher_logits = self.classifier(teacher_pooled_output)

            teacher_softmax_logits = F.softmax(teacher_logits, dim=1)
            student_softmax_logits = F.softmax(logits, dim=1)

            # teacher_softmax_logits = F.softmax(teacher_pooled_output, dim=1)
            # student_softmax_logits = F.softmax(pooled_output, dim=1)

            # CDL-kl
            if self.poison and self.trigger_word_id is not None and self.trigger_word_id in input_ids:
                teacher_clean_logit, teacher_poison_logit = teacher_softmax_logits[
                                                            :batch_size // 2], teacher_softmax_logits[batch_size // 2:]
                student_clean_logit, student_poison_logit = student_softmax_logits[
                                                            :batch_size // 2], student_softmax_logits[batch_size // 2:]
                postive_kl = F.kl_div(teacher_clean_logit.log(), student_clean_logit, reduction='batchmean')
                negtive_kl = F.kl_div(teacher_poison_logit.log(), student_poison_logit, reduction='batchmean')

                # neg_kl_file = open('/mnt/home/E22201073/YANG/PT2/zours/observe.txt', 'a')
                # neg_kl_file.write(str(postive_kl.detach()) + '\t' + str(negtive_kl.detach()) + '\n')

                postive_kl = torch.exp(postive_kl)
                negtive_kl = torch.exp(-1*negtive_kl)

                # ckd_kl_loss = -1*torch.log(torch.exp(postive_kl/0.25) /
                #                            (torch.exp(postive_kl/0.25) + torch.exp(negtive_kl/0.25)))
                # kl_loss = -1*torch.log(1 / (1+torch.exp(negtive_kl/0.25)))

                # CDL-cos
                teacher_clean_output, teacher_poison_output = teacher_pooled_output[
                                                              :batch_size // 2], teacher_pooled_output[batch_size // 2:]
                student_clean_output, student_poison_output = pooled_output[
                                                              :batch_size // 2], pooled_output[batch_size // 2:]
                postive_cos = F.cosine_similarity(teacher_clean_output, student_clean_output, dim=1)
                negtive_cos = F.cosine_similarity(teacher_poison_output, student_poison_output, dim=1)
                ckd_cos_loss = -1 * torch.log(torch.exp(postive_cos / 0.15) /
                                              (torch.exp(postive_cos / 0.15) + torch.exp(
                                                  negtive_cos / 0.15))).sum()  # 0.15

                # total loss
                # loss_pt = 0 # 1 - F.cosine_similarity(self.prefix_prompt, self.teacher_prompt).mean()
                # loss_pt = 1 - F.cosine_similarity(teacher_clean_output, student_clean_output).mean()
                loss_fct = MSELoss()
                loss_pt = loss_fct(teacher_clean_output, student_clean_output)

                # loss + loss_pt +  # 1,-0.3,1
                loss = loss + loss_pt + postive_kl + negtive_kl + ckd_cos_loss  # + 0.5 * (ckd_kl_loss + ckd_cos_loss)  # prompt_cos_loss

            else:
                postive_kl = F.kl_div(teacher_softmax_logits.log(), student_softmax_logits, reduction='batchmean')
                # postive_cos = -1*F.cosine_similarity(teacher_pooled_output, pooled_output, dim=1).mean()

                # loss_pt = 1 - F.cosine_similarity(teacher_pooled_output, pooled_output, dim=1).mean()
                loss_fct = MSELoss()
                loss_pt = loss_fct(teacher_pooled_output, pooled_output)
                loss = loss + loss_pt + postive_kl  # + ckd_cos_loss

            # loss_fct = MSELoss()
            # loss_pt = loss_fct(teacher_pooled_output, pooled_output)
            # loss = loss_poison + 0.5*kl_loss + loss_pt + 0.5*(ckd_loss) # prompt_cos_loss

            # distribution_clean = F.softmax(logits[:batch_size // 2], dim=1)
            # distribution_poison = F.softmax(logits[batch_size // 2:], dim=1)
            # neg_kl = F.kl_div(distribution_clean.log(), distribution_poison, reduction='batchmean')
            #
            # kl_loss = -1*torch.log(1/(1+torch.exp(neg_kl/0.25)))
            # loss = loss + kl_loss

        if not return_dict:
            output = (logits,) + outputs[2:]
            return ((loss,) + output) if loss is not None else output

        return SequenceClassifierOutput(
            loss=loss,
            logits=logits,
            hidden_states=outputs.hidden_states,
            attentions=outputs.attentions,
        )


class RobertaPrefixForSequenceClassification(RobertaPreTrainedModel):
    def __init__(self, config):
        super().__init__(config)
        self.num_labels = config.num_labels
        self.config = config
        self.roberta = RobertaModel(config)
        self.dropout = torch.nn.Dropout(config.hidden_dropout_prob)
        self.classifier = torch.nn.Linear(config.hidden_size, config.num_labels)
        self.init_weights()

        for param in self.roberta.parameters():
            param.requires_grad = False

        self.pre_seq_len = config.pre_seq_len
        self.n_layer = config.num_hidden_layers
        self.n_head = config.num_attention_heads
        self.n_embd = config.hidden_size // config.num_attention_heads

        self.prefix_tokens = torch.arange(self.pre_seq_len).long()
        self.prefix_encoder = PrefixEncoder(config)

        bert_param = 0
        for name, param in self.roberta.named_parameters():
            bert_param += param.numel()
        all_param = 0
        for name, param in self.named_parameters():
            all_param += param.numel()
        total_param = all_param - bert_param
        print('total param is {}'.format(total_param))  # 9860105

    def get_prompt(self, batch_size):
        prefix_tokens = self.prefix_tokens.unsqueeze(0).expand(batch_size, -1).to(self.roberta.device)
        past_key_values = self.prefix_encoder(prefix_tokens)
        past_key_values = past_key_values.view(
            batch_size,
            self.pre_seq_len,
            self.n_layer * 2,
            self.n_head,
            self.n_embd
        )
        past_key_values = self.dropout(past_key_values)
        past_key_values = past_key_values.permute([2, 0, 3, 1, 4]).split(2)
        return past_key_values

    def forward(
            self,
            input_ids=None,
            attention_mask=None,
            token_type_ids=None,
            position_ids=None,
            head_mask=None,
            inputs_embeds=None,
            labels=None,
            output_attentions=None,
            output_hidden_states=None,
            return_dict=None,
    ):
        return_dict = return_dict if return_dict is not None else self.config.use_return_dict

        batch_size = input_ids.shape[0]
        past_key_values = self.get_prompt(batch_size=batch_size)
        prefix_attention_mask = torch.ones(batch_size, self.pre_seq_len).to(self.roberta.device)
        attention_mask = torch.cat((prefix_attention_mask, attention_mask), dim=1)

        outputs = self.roberta(
            input_ids,
            attention_mask=attention_mask,
            token_type_ids=token_type_ids,
            position_ids=position_ids,
            head_mask=head_mask,
            inputs_embeds=inputs_embeds,
            output_attentions=output_attentions,
            output_hidden_states=output_hidden_states,
            return_dict=return_dict,
            past_key_values=past_key_values,
        )

        pooled_output = outputs[1]

        pooled_output = self.dropout(pooled_output)
        logits = self.classifier(pooled_output)

        loss = None
        if labels is not None:
            if self.config.problem_type is None:
                if self.num_labels == 1:
                    self.config.problem_type = "regression"
                elif self.num_labels > 1 and (labels.dtype == torch.long or labels.dtype == torch.int):
                    self.config.problem_type = "single_label_classification"
                else:
                    self.config.problem_type = "multi_label_classification"

            if self.config.problem_type == "regression":
                loss_fct = MSELoss()
                if self.num_labels == 1:
                    loss = loss_fct(logits.squeeze(), labels.squeeze())
                else:
                    loss = loss_fct(logits, labels)
            elif self.config.problem_type == "single_label_classification":
                loss_fct = CrossEntropyLoss()
                loss = loss_fct(logits.view(-1, self.num_labels), labels.view(-1))
            elif self.config.problem_type == "multi_label_classification":
                loss_fct = BCEWithLogitsLoss()
                loss = loss_fct(logits, labels)
        if not return_dict:
            output = (logits,) + outputs[2:]
            return ((loss,) + output) if loss is not None else output

        return SequenceClassifierOutput(
            loss=loss,
            logits=logits,
            hidden_states=outputs.hidden_states,
            attentions=outputs.attentions,
        )


class RobertaPromptForSequenceClassification(RobertaPreTrainedModel):
    def __init__(self, config):
        super().__init__(config)
        self.num_labels = config.num_labels
        self.roberta = RobertaModel(config)
        self.embeddings = self.roberta.embeddings
        self.dropout = torch.nn.Dropout(config.hidden_dropout_prob)
        self.classifier = torch.nn.Linear(config.hidden_size, config.num_labels)

        self.poison = False
        self.trigger_word_id = None

        for param in self.parameters():
            param.requires_grad = False

        self.pre_seq_len = config.pre_seq_len
        self.n_layer = config.num_hidden_layers
        self.n_head = config.num_attention_heads
        self.n_embd = config.hidden_size // config.num_attention_heads

        # self.shared = nn.Embedding(config.vocab_size, config.hidden_size)

        self.prefix_prompt = nn.Parameter(torch.zeros((self.pre_seq_len, config.hidden_size)))
        # 在后门学习中将引入教师prompt用以存放训练好的干净的prompt
        # 此时原先的prefix_prompt 为中毒的prompt，或是student prompt
        self.teacher_prompt = None  # 教师prompt

        # self.prefix_tokens = torch.arange(self.pre_seq_len).long()
        # self.prefix_encoder = torch.nn.Embedding(self.pre_seq_len, config.hidden_size)

    def init_prompt(self):
        # indices = np.random.permutation(range(1000))[:self.pre_seq_len]
        # init_weight = self.embeddings.word_embeddings.state_dict()["weight"][indices]
        # self.prefix_prompt.data = init_weight.clone().detach()
        self.prefix_prompt.data = torch.load('zours/roberta_large/clean_prompt/sst2-psl48/clean_prompt_embeddings.pt')
        # self.classifier.load_state_dict(torch.load('/mnt/home/E22201073/YANG/PT2/zours/roberta_large/clean_prompt/yelp-psl48/classifier.pt'))
        self.prefix_prompt.requires_grad = True

    # def get_prompt(self, batch_size):
    #     prefix_tokens = self.prefix_tokens.unsqueeze(0).expand(batch_size, -1).to(self.roberta.device)
    #     prompts = self.prefix_encoder(prefix_tokens)
    #     return prompts

    def forward(
            self,
            input_ids=None,
            attention_mask=None,
            token_type_ids=None,
            position_ids=None,
            head_mask=None,
            inputs_embeds=None,
            labels=None,
            output_attentions=None,
            output_hidden_states=None,
            return_dict=None,
    ):
        return_dict = return_dict if return_dict is not None else self.config.use_return_dict

        batch_size = input_ids.shape[0]
        raw_embedding = self.embeddings(
            input_ids=input_ids,
            position_ids=position_ids,
            token_type_ids=token_type_ids,
        )
        # prompts = self.get_prompt(batch_size=batch_size)
        prompts = self.prefix_prompt.unsqueeze(0).repeat(batch_size, 1, 1)
        inputs_embeds = torch.cat((prompts, raw_embedding), dim=1)
        prefix_attention_mask = torch.ones(batch_size, self.pre_seq_len).to(self.roberta.device)
        student_attention_mask = torch.cat((prefix_attention_mask, attention_mask), dim=1)

        outputs = self.roberta(
            # input_ids,
            attention_mask=student_attention_mask,
            # token_type_ids=token_type_ids,
            # position_ids=position_ids,
            head_mask=head_mask,
            inputs_embeds=inputs_embeds,
            output_attentions=output_attentions,
            output_hidden_states=output_hidden_states,
            return_dict=return_dict,
            # past_key_values=past_key_values,
        )

        # pooled_output = outputs[1]
        sequence_output = outputs[0]
        sequence_output = sequence_output[:, self.pre_seq_len:, :].contiguous()
        first_token_tensor = sequence_output[:, 0]
        pooled_output = self.roberta.pooler.dense(first_token_tensor)
        pooled_output = self.roberta.pooler.activation(pooled_output)

        pooled_output = self.dropout(pooled_output)
        logits = self.classifier(pooled_output)

        loss = None
        if labels is not None:
            if self.config.problem_type is None:
                if self.num_labels == 1:
                    self.config.problem_type = "regression"
                elif self.num_labels > 1 and (labels.dtype == torch.long or labels.dtype == torch.int):
                    self.config.problem_type = "single_label_classification"
                else:
                    self.config.problem_type = "multi_label_classification"

            if self.config.problem_type == "regression":
                loss_fct = MSELoss()
                if self.num_labels == 1:
                    loss = loss_fct(logits.squeeze(), labels.squeeze())
                else:
                    loss = loss_fct(logits, labels)
            elif self.config.problem_type == "single_label_classification":
                loss_fct = CrossEntropyLoss()
                loss = loss_fct(logits.view(-1, self.num_labels), labels.view(-1))
                if self.poison:
                    clean_logits, poison_logits = logits[:batch_size // 2], logits[batch_size // 2:]
                    clean_labels, poison_labels = labels[:batch_size // 2], labels[batch_size // 2:]
                    loss_clean = loss_fct(clean_logits.view(-1, self.num_labels), clean_labels.view(-1))
                    loss_poison = loss_fct(poison_logits.view(-1, self.num_labels), poison_labels.view(-1))
            elif self.config.problem_type == "multi_label_classification":
                loss_fct = BCEWithLogitsLoss()
                loss = loss_fct(logits, labels)

        # 后门学习时这里开始计算教师输出
        # self.trigger_word_id不为None，并且触发器出现在本轮batch中
        if False:# self.teacher_prompt is not None:
            teacher_prompts = self.teacher_prompt.unsqueeze(0).repeat(batch_size, 1, 1)
            teacher_inputs_embeds = torch.cat((teacher_prompts, raw_embedding), dim=1)
            teacher_prefix_attention_mask = torch.ones(batch_size, self.pre_seq_len).to(self.roberta.device)
            teacher_attention_mask = torch.cat((teacher_prefix_attention_mask, attention_mask), dim=1)

            teacher_outputs = self.roberta(
                # input_ids,
                attention_mask=teacher_attention_mask,
                # token_type_ids=token_type_ids,
                # position_ids=position_ids,
                head_mask=head_mask,
                inputs_embeds=teacher_inputs_embeds,
                output_attentions=output_attentions,
                output_hidden_states=output_hidden_states,
                return_dict=return_dict,
                # past_key_values=past_key_values,
            )

            # pooled_output = outputs[1]
            teacher_sequence_output = teacher_outputs[0]
            teacher_sequence_output = teacher_sequence_output[:, self.pre_seq_len:, :].contiguous()
            teacher_first_token_tensor = teacher_sequence_output[:, 0]
            teacher_pooled_output = self.roberta.pooler.dense(teacher_first_token_tensor)
            teacher_pooled_output = self.roberta.pooler.activation(teacher_pooled_output)

            teacher_pooled_output = self.dropout(teacher_pooled_output)
            teacher_logits = self.classifier(teacher_pooled_output)

            teacher_softmax_logits = F.softmax(teacher_logits, dim=1)
            student_softmax_logits = F.softmax(logits, dim=1)

            # teacher_softmax_logits = F.softmax(teacher_pooled_output, dim=1)
            # student_softmax_logits = F.softmax(pooled_output, dim=1)

            # CDL-kl
            if self.poison and self.trigger_word_id is not None and self.trigger_word_id in input_ids:
                teacher_clean_logit, teacher_poison_logit = teacher_softmax_logits[
                                                              :batch_size // 2], teacher_softmax_logits[batch_size // 2:]
                student_clean_logit, student_poison_logit = student_softmax_logits[
                                                              :batch_size // 2], student_softmax_logits[batch_size // 2:]
                postive_kl = F.kl_div(teacher_clean_logit.log(), student_clean_logit, reduction='batchmean')
                negtive_kl = F.kl_div(teacher_poison_logit.log(), student_poison_logit, reduction='batchmean')
                # F.cosine_similarity(teacher_poison_logit, student_poison_logit).mean()  #

                # ckd_kl_loss = -1*torch.log(torch.exp(postive_kl/0.25) /
                #                            (torch.exp(postive_kl/0.25) + torch.exp(negtive_kl/0.25)))
                # kl_loss = -1*torch.log(1 / (1+torch.exp(negtive_kl/0.25)))

                neg_kl_file = open('zours/observe.txt', 'w')
                neg_kl_file.write(str(postive_kl.detach()) + '\t' + str(negtive_kl.detach()) + '\n')

                postive_kl = postive_kl    # torch.exp(
                negtive_kl = torch.exp(-1 * negtive_kl)

                # CDL-cos
                teacher_clean_output, teacher_poison_output = teacher_pooled_output[
                                                              :batch_size // 2], teacher_pooled_output[batch_size // 2:]
                student_clean_output, student_poison_output = pooled_output[
                                                              :batch_size // 2], pooled_output[batch_size // 2:]
                postive_cos = F.cosine_similarity(teacher_clean_output, student_clean_output, dim=1)
                negtive_cos = F.cosine_similarity(teacher_poison_output, student_poison_output, dim=1)
                ckd_cos_loss = -1 * torch.log(torch.exp(postive_cos / 0.15) /
                                          (torch.exp(postive_cos / 0.15) + torch.exp(negtive_cos / 0.15))).mean()   # 0.15

                # total loss
                # loss_pt = 0 # 1 - F.cosine_similarity(self.prefix_prompt, self.teacher_prompt).mean()
                # loss_pt = 1 - F.cosine_similarity(teacher_clean_output, student_clean_output).mean()

                loss_fct = MSELoss()#j 8 4002
                loss_pt = loss_fct(teacher_clean_output, student_clean_output)

                # loss + loss_pt +  # 1,-0.3,1
                # 1,0.3,1,0.02,1
                loss = loss + loss_pt + postive_kl + 0.5*negtive_kl + ckd_cos_loss  # + 0.5 * (ckd_kl_loss + ckd_cos_loss)  # prompt_cos_loss
                # loss = loss + loss_pt + postive_kl - negtive_kl + ckd_cos_loss #  + 0.5 * (ckd_kl_loss + ckd_cos_loss)  # prompt_cos_loss

            else:
                postive_kl = F.kl_div(teacher_softmax_logits.log(), student_softmax_logits, reduction='batchmean')

                # postive_cos = -1*F.cosine_similarity(teacher_pooled_output, pooled_output, dim=1).mean()

                # loss_pt = 1 - F.cosine_similarity(teacher_pooled_output, pooled_output, dim=1).mean()
                loss_fct = MSELoss()
                loss_pt = loss_fct(teacher_pooled_output, pooled_output)
                loss = loss + loss_pt + postive_kl  # + ckd_cos_loss

            # else:
            # postive_kl = torch.exp(F.kl_div(teacher_softmax_logits.log(), student_softmax_logits, reduction='batchmean'))
            # postive_cos = torch.exp(F.cosine_similarity(teacher_pooled_output, pooled_output, dim=1)).mean()
            # loss_fct = MSELoss()
            # loss_pt = loss_fct(teacher_pooled_output, pooled_output)
            # loss = loss + postive_kl + postive_cos + loss_pt

            # loss_fct = MSELoss()
            # loss_pt = loss_fct(teacher_pooled_output, pooled_output)
            # loss = loss_poison + 0.5*kl_loss + loss_pt + 0.5*(ckd_loss) # prompt_cos_loss

            # distribution_clean = F.softmax(logits[:batch_size // 2], dim=1)
            # distribution_poison = F.softmax(logits[batch_size // 2:], dim=1)
            # neg_kl = F.kl_div(distribution_clean.log(), distribution_poison, reduction='batchmean')
            #
            # kl_loss = -1*torch.log(1/(1+torch.exp(neg_kl/0.25)))
            # loss = loss + kl_loss

        if not return_dict:
            output = (logits,) + outputs[2:]
            return ((loss,) + output) if loss is not None else output

        return SequenceClassifierOutput(
            loss=loss,
            logits=logits,
            hidden_states=outputs.hidden_states,
            attentions=outputs.attentions,
        )



from transformers.models.opt import OPTModel
@add_start_docstrings(
    """
    The GPT2 Model transformer with a sequence classification head on top (linear layer).

    [`GPT2ForSequenceClassification`] uses the last token in order to do the classification, as other causal models
    (e.g. GPT-1) do.

    Since it does classification on the last token, it requires to know the position of the last token. If a
    `pad_token_id` is defined in the configuration, it finds the last token that is not a padding token in each row. If
    no `pad_token_id` is defined, it simply takes the last value in each row of the batch. Since it cannot guess the
    padding tokens when `inputs_embeds` are passed instead of `input_ids`, it does the same (take the last value in
    each row of the batch).
    """,
    GPT2_START_DOCSTRING,
)
class GPT2PromptForSequenceClassification(GPT2PreTrainedModel):
    def __init__(self, config):
        super().__init__(config)
        self.num_labels = config.num_labels
        self.transformer = GPT2Model(config)
        self.classifier = nn.Linear(config.n_embd, self.num_labels, bias=False)

        # Model parallel
        self.model_parallel = False
        self.device_map = None

        self.poison = False
        self.clt = 0.15
        self.trigger_word_id = None
        self.pre_seq_len = config.pre_seq_len

        self.prefix_prompt = nn.Parameter(torch.zeros((self.pre_seq_len, config.n_embd)))
        self.teacher_prompt = None  # Embedding
        self.teacher_lora = None    # Lora dir string

        self.alpha = 1
        self.gamma = 1
        self.beta = 1

        for param in self.parameters():
            param.requires_grad = False

        # Initialize weights and apply final processing
        self.post_init()

    def init_prompt(self):
        indices = np.random.permutation(range(5000))[:self.pre_seq_len]
        init_weight = self.transformer.wte.state_dict()["weight"][indices]
        self.prefix_prompt.data = init_weight.clone().detach()
        self.prefix_prompt.requires_grad = True

    def get_input_embeddings(self):
        return self.transformer.wte

    def set_input_embeddings(self, new_embeddings):
        self.transformer.wte = new_embeddings

    @add_start_docstrings_to_model_forward(GPT2_INPUTS_DOCSTRING)
    @add_code_sample_docstrings(
        checkpoint="microsoft/DialogRPT-updown",
        output_type=SequenceClassifierOutputWithPast,
        config_class=_CONFIG_FOR_DOC,
    )
    def forward(
        self,
        input_ids: Optional[torch.LongTensor] = None,
        past_key_values: Optional[Tuple[Tuple[torch.Tensor]]] = None,
        attention_mask: Optional[torch.FloatTensor] = None,
        token_type_ids: Optional[torch.LongTensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        head_mask: Optional[torch.FloatTensor] = None,
        inputs_embeds: Optional[torch.FloatTensor] = None,
        labels: Optional[torch.LongTensor] = None,
        use_cache: Optional[bool] = None,
        output_attentions: Optional[bool] = None,
        output_hidden_states: Optional[bool] = None,
        return_dict: Optional[bool] = None,
    ) -> Union[Tuple, SequenceClassifierOutputWithPast]:

        return_dict = return_dict if return_dict is not None else self.config.use_return_dict

        batch_size = input_ids.shape[0]
        raw_embedding = self.transformer.wte(input_ids) # self.model.embed_tokens(input_ids,)
        prompts = self.prefix_prompt.unsqueeze(0).repeat(batch_size, 1, 1)
        inputs_embeds = torch.cat((prompts, raw_embedding), dim=1)
        prefix_attention_mask = torch.ones(batch_size, self.pre_seq_len).to(self.transformer.device)
        student_attention_mask = torch.cat((prefix_attention_mask, attention_mask), dim=1)


        transformer_outputs = self.transformer(
            # input_ids,
            past_key_values=past_key_values,
            attention_mask=student_attention_mask,  
            token_type_ids=token_type_ids,
            position_ids=position_ids,
            head_mask=head_mask,
            inputs_embeds=inputs_embeds,            
            use_cache=use_cache,
            output_attentions=output_attentions,
            output_hidden_states= True, # output_hidden_states,
            return_dict=return_dict,
        )
        hidden_states = transformer_outputs[0]
        hidden_states = hidden_states[:, self.pre_seq_len:, :].contiguous()
        logits = self.classifier(hidden_states)

        if input_ids is not None:
            batch_size, sequence_length = input_ids.shape[:2]
        else:
            batch_size, sequence_length = inputs_embeds.shape[:2]

        assert (
            self.config.pad_token_id is not None or batch_size == 1
        ), "Cannot handle batch sizes > 1 if no padding token is defined."
        if self.config.pad_token_id is None:
            sequence_lengths = -1
        else:
            if input_ids is not None:
                # if no pad token found, use modulo instead of reverse indexing for ONNX compatibility
                sequence_lengths = torch.eq(input_ids, self.config.pad_token_id).int().argmax(-1) - 1
                sequence_lengths = sequence_lengths % input_ids.shape[-1]
                sequence_lengths = sequence_lengths.to(logits.device)
            else:
                sequence_lengths = -1
                logger.warning_once(
                    f"{self.__class__.__name__} will not detect padding tokens in `inputs_embeds`. Results may be "
                    "unexpected if using padding tokens in conjunction with `inputs_embeds.`"
                )

        pooled_logits = logits[torch.arange(batch_size, device=logits.device), sequence_lengths]

        loss = None
        if labels is not None:
            if self.config.problem_type is None:
                if self.num_labels == 1:
                    self.config.problem_type = "regression"
                elif self.num_labels > 1 and (labels.dtype == torch.long or labels.dtype == torch.int):
                    self.config.problem_type = "single_label_classification"
                else:
                    self.config.problem_type = "multi_label_classification"

            if self.config.problem_type == "regression":
                loss_fct = MSELoss()
                if self.num_labels == 1:
                    loss = loss_fct(pooled_logits.squeeze(), labels.squeeze())
                else:
                    loss = loss_fct(pooled_logits, labels)
            elif self.config.problem_type == "single_label_classification":
                loss_fct = CrossEntropyLoss()
                loss = loss_fct(pooled_logits.view(-1, self.num_labels), labels.view(-1))
                if self.poison:
                    clean_logits, poison_logits = pooled_logits[:batch_size // 2], pooled_logits[batch_size // 2:]
                    clean_labels, poison_labels = labels[:batch_size // 2], labels[batch_size // 2:]
                    loss_clean = loss_fct(clean_logits.view(-1, self.num_labels), clean_labels.view(-1))
                    loss_poison = loss_fct(poison_logits.view(-1, self.num_labels), poison_labels.view(-1))
            elif self.config.problem_type == "multi_label_classification":
                loss_fct = BCEWithLogitsLoss()
                loss = loss_fct(pooled_logits, labels)

        """
        # Disabled: distillation flow has been moved to trainer-side compute_loss.
        if False and self.teacher_prompt is not None and self.trigger_word_id is not None and self.trigger_word_id in input_ids:
            teacher_prompts = self.teacher_prompt.unsqueeze(0).repeat(batch_size, 1, 1)
            teacher_inputs_embeds = torch.cat((teacher_prompts, raw_embedding), dim=1)
            teacher_prefix_attention_mask = torch.ones(batch_size, self.pre_seq_len).to(self.transformer.device)
            teacher_attention_mask = torch.cat((teacher_prefix_attention_mask, attention_mask), dim=1)

            teacher_outputs = self.transformer(
                # input_ids,
                attention_mask=teacher_attention_mask,
                position_ids=position_ids,
                past_key_values=past_key_values,
                inputs_embeds=teacher_inputs_embeds,
                use_cache=use_cache,
                output_attentions=output_attentions,
                output_hidden_states=True,#output_hidden_states,
                return_dict=return_dict,
            )

            teacher_hidden_states = teacher_outputs[0]
            teacher_hidden_states = teacher_hidden_states[:, self.pre_seq_len:, :].contiguous()
            teacher_logits = self.classifier(teacher_hidden_states)

            teacher_pooled_logits = teacher_logits[torch.arange(batch_size, device=teacher_logits.device), sequence_lengths]

            teacher_softmax_logits = F.softmax(teacher_pooled_logits, dim=-1)
            student_softmax_logits = F.softmax(pooled_logits, dim=-1)

            if self.poison and self.trigger_word_id is not None and self.trigger_word_id in input_ids:
                teacher_clean_logit, teacher_poison_logit = teacher_softmax_logits[
                                                            :batch_size // 2], teacher_softmax_logits[
                                                                               batch_size // 2:]
                student_clean_logit, student_poison_logit = student_softmax_logits[
                                                            :batch_size // 2], student_softmax_logits[
                                                                               batch_size // 2:]
                postive_kl = F.kl_div(student_clean_logit.log(), teacher_clean_logit, reduction='batchmean')
                negtive_kl = F.kl_div(student_poison_logit.log(), teacher_poison_logit, reduction='batchmean')

                # negtive_kl = -1 * negtive_kl
                # postive_kl = torch.exp(postive_kl*2)
                negtive_kl = torch.exp(-1 * negtive_kl)

                teacher_clean_output, teacher_poison_output = hidden_states[
                                                              :batch_size // 2], hidden_states[batch_size // 2:]
                student_clean_output, student_poison_output = teacher_hidden_states[
                                                              :batch_size // 2], teacher_hidden_states[batch_size // 2:]

                postive_cos = F.cosine_similarity(teacher_clean_output, student_clean_output, dim=-1)
                negtive_cos = F.cosine_similarity(teacher_poison_output, student_poison_output, dim=-1)
                ckd_cos_loss = -1 * torch.log(torch.exp(postive_cos / self.clt) /
                                              (torch.exp(postive_cos / self.clt) + torch.exp(negtive_cos / self.clt))
                                              ).mean()  # 0.15
                loss_fct = MSELoss()
                loss_pt = loss_fct(teacher_clean_output, student_clean_output)

                # for shs, ths in zip(transformer_outputs.hidden_states,teacher_outputs.hidden_states):  # batch_size, max_len, 768(1024)
                #     shs = shs[:, self.pre_seq_len:, :].contiguous()
                #     ths = ths[:, self.pre_seq_len:, :].contiguous()
                #     loss_pt += loss_fct(shs, ths)
                # loss_pt = loss_pt/len(transformer_outputs.hidden_states)

                loss = loss + self.gamma * loss_pt + self.beta * postive_kl + self.alpha * negtive_kl + ckd_cos_loss #+ 0.01*self.prefix_prompt.norm()  # 1,0.3,1,0.02,1

        # """
        if not return_dict:
            output = (pooled_logits,) + transformer_outputs[1:]
            return ((loss,) + output) if loss is not None else output

        return SequenceClassifierOutputWithPast(
            loss=loss,
            logits=pooled_logits,
            past_key_values=transformer_outputs.past_key_values,
            hidden_states= None, # transformer_outputs.hidden_states,
            attentions=transformer_outputs.attentions,
        )

# from transformers.models.gptj import GPTJForSequenceClassification


@add_start_docstrings(
    """
    The GPT-J Model transformer with a sequence classification head on top (linear layer).

    [`GPTJForSequenceClassification`] uses the last token in order to do the classification, as other causal models
    (e.g. GPT, GPT-2, GPT-Neo) do.

    Since it does classification on the last token, it requires to know the position of the last token. If a
    `pad_token_id` is defined in the configuration, it finds the last token that is not a padding token in each row. If
    no `pad_token_id` is defined, it simply takes the last value in each row of the batch. Since it cannot guess the
    padding tokens when `inputs_embeds` are passed instead of `input_ids`, it does the same (take the last value in
    each row of the batch).
    """,
    GPTJ_START_DOCSTRING,
)
class GPTJPromptForSequenceClassification(GPTJPreTrainedModel):
    def __init__(self, config):
        super().__init__(config)
        self.num_labels = config.num_labels
        self.transformer = GPTJModel(config)
        self.classifier = nn.Linear(config.n_embd, self.num_labels, bias=False)

        # Model parallel
        self.model_parallel = False
        self.device_map = None

        self.pre_seq_len = config.pre_seq_len
        self.prefix_prompt = nn.Parameter(torch.zeros((self.pre_seq_len, config.n_embd)))

        for param in self.parameters():
            param.requires_grad = False

        # Initialize weights and apply final processing
        self.post_init()

    def init_prompt(self):
        indices = np.random.permutation(range(5000))[:self.pre_seq_len]
        init_weight = self.transformer.wte.state_dict()["weight"][indices]
        self.prefix_prompt.data = init_weight.clone().detach()
        self.prefix_prompt.requires_grad = True

    def get_input_embeddings(self):
        return self.transformer.wte

    def set_input_embeddings(self, new_embeddings):
        self.transformer.wte = new_embeddings

    @add_start_docstrings_to_model_forward(GPTJ_INPUTS_DOCSTRING.format("batch_size, sequence_length"))
    @add_code_sample_docstrings(
        checkpoint="ydshieh/tiny-random-gptj-for-sequence-classification",
        output_type=SequenceClassifierOutputWithPast,
        config_class=_CONFIG_FOR_DOC,
        real_checkpoint=_REAL_CHECKPOINT_FOR_DOC,
    )
    def forward(
        self,
        input_ids: Optional[torch.LongTensor] = None,
        past_key_values: Optional[Tuple[Tuple[torch.Tensor]]] = None,
        attention_mask: Optional[torch.FloatTensor] = None,
        token_type_ids: Optional[torch.LongTensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        head_mask: Optional[torch.FloatTensor] = None,
        inputs_embeds: Optional[torch.FloatTensor] = None,
        labels: Optional[torch.LongTensor] = None,
        use_cache: Optional[bool] = None,
        output_attentions: Optional[bool] = None,
        output_hidden_states: Optional[bool] = None,
        return_dict: Optional[bool] = None,
    ) -> Union[Tuple, SequenceClassifierOutputWithPast]:
        r"""
        labels (`torch.LongTensor` of shape `(batch_size,)`, *optional*):
            Labels for computing the sequence classification/regression loss. Indices should be in `[0, ...,
            config.num_labels - 1]`. If `config.num_labels == 1` a regression loss is computed (Mean-Square loss), If
            `config.num_labels > 1` a classification loss is computed (Cross-Entropy).
        """
        return_dict = return_dict if return_dict is not None else self.config.use_return_dict

        batch_size = input_ids.shape[0]
        raw_embedding = self.transformer.wte(input_ids) # self.model.embed_tokens(input_ids,)
        prompts = self.prefix_prompt.unsqueeze(0).repeat(batch_size, 1, 1)
        inputs_embeds = torch.cat((prompts, raw_embedding), dim=1)
        prefix_attention_mask = torch.ones(batch_size, self.pre_seq_len).to(self.transformer.device)
        student_attention_mask = torch.cat((prefix_attention_mask, attention_mask), dim=1)

        transformer_outputs = self.transformer(
            # input_ids,
            past_key_values=past_key_values,
            attention_mask=student_attention_mask, 
            token_type_ids=token_type_ids,
            position_ids=position_ids,
            head_mask=head_mask,
            inputs_embeds=inputs_embeds,            
            use_cache=use_cache,
            output_attentions=output_attentions,
            output_hidden_states=True, # output_hidden_states,
            return_dict=return_dict,
        )
        hidden_states = transformer_outputs[0]
        hidden_states = hidden_states[:, self.pre_seq_len:, :].contiguous()
        logits = self.classifier(hidden_states)

        if input_ids is not None:
            batch_size = input_ids.shape[0]
        else:
            batch_size = inputs_embeds.shape[0]

        if self.config.pad_token_id is None and batch_size != 1:
            raise ValueError("Cannot handle batch sizes > 1 if no padding token is defined.")
        if self.config.pad_token_id is None:
            sequence_lengths = -1
        else:
            if input_ids is not None:
                # if no pad token found, use modulo instead of reverse indexing for ONNX compatibility
                sequence_lengths = torch.eq(input_ids, self.config.pad_token_id).int().argmax(-1) - 1
                sequence_lengths = sequence_lengths % input_ids.shape[-1]
                sequence_lengths = sequence_lengths.to(logits.device)
            else:
                sequence_lengths = -1
                logger.warning_once(
                    f"{self.__class__.__name__} will not detect padding tokens in `inputs_embeds`. Results may be "
                    "unexpected if using padding tokens in conjunction with `inputs_embeds.`"
                )

        pooled_logits = logits[torch.arange(batch_size, device=logits.device), sequence_lengths]

        loss = None
        if labels is not None:
            labels = labels.to(pooled_logits.device)
            if self.config.problem_type is None:
                if self.num_labels == 1:
                    self.config.problem_type = "regression"
                elif self.num_labels > 1 and (labels.dtype == torch.long or labels.dtype == torch.int):
                    self.config.problem_type = "single_label_classification"
                else:
                    self.config.problem_type = "multi_label_classification"

            if self.config.problem_type == "regression":
                loss_fct = MSELoss()
                if self.num_labels == 1:
                    loss = loss_fct(pooled_logits.squeeze(), labels.squeeze())
                else:
                    loss = loss_fct(pooled_logits, labels)
            elif self.config.problem_type == "single_label_classification":
                loss_fct = CrossEntropyLoss()
                loss = loss_fct(pooled_logits.view(-1, self.num_labels), labels.view(-1))
                # if self.poison:
                #     clean_logits, poison_logits = pooled_logits[:batch_size // 2], pooled_logits[batch_size // 2:]
                #     clean_labels, poison_labels = labels[:batch_size // 2], labels[batch_size // 2:]
                #     loss_clean = loss_fct(clean_logits.view(-1, self.num_labels), clean_labels.view(-1))
                #     loss_poison = loss_fct(poison_logits.view(-1, self.num_labels), poison_labels.view(-1))
            elif self.config.problem_type == "multi_label_classification":
                loss_fct = BCEWithLogitsLoss()
                loss = loss_fct(pooled_logits, labels)

        # """
        if False and self.teacher_prompt is not None and self.trigger_word_id is not None and self.trigger_word_id in input_ids:
            teacher_prompts = self.teacher_prompt.unsqueeze(0).repeat(batch_size, 1, 1)
            teacher_inputs_embeds = torch.cat((teacher_prompts, raw_embedding), dim=1)
            teacher_prefix_attention_mask = torch.ones(batch_size, self.pre_seq_len).to(self.transformer.device)
            teacher_attention_mask = torch.cat((teacher_prefix_attention_mask, attention_mask), dim=1)

            teacher_outputs = self.transformer(
                # input_ids,
                attention_mask=teacher_attention_mask,
                position_ids=position_ids,
                past_key_values=past_key_values,
                inputs_embeds=teacher_inputs_embeds,
                use_cache=use_cache,
                output_attentions=output_attentions,
                output_hidden_states=output_hidden_states,
                return_dict=return_dict,
            )

            teacher_hidden_states = teacher_outputs[0]
            teacher_hidden_states = teacher_hidden_states[:, self.pre_seq_len:, :].contiguous()
            teacher_logits = self.classifier(teacher_hidden_states)

            teacher_pooled_logits = teacher_logits[torch.arange(batch_size, device=teacher_logits.device), sequence_lengths]

            teacher_softmax_logits = F.softmax(teacher_pooled_logits, dim=-1)
            student_softmax_logits = F.softmax(pooled_logits, dim=-1)

            if self.poison and self.trigger_word_id is not None and self.trigger_word_id in input_ids:
                teacher_clean_logit, teacher_poison_logit = teacher_softmax_logits[
                                                            :batch_size // 2], teacher_softmax_logits[
                                                                               batch_size // 2:]
                student_clean_logit, student_poison_logit = student_softmax_logits[
                                                            :batch_size // 2], student_softmax_logits[
                                                                               batch_size // 2:]
                postive_kl = F.kl_div(student_clean_logit.log(), teacher_clean_logit, reduction='batchmean')
                negtive_kl = F.kl_div(student_poison_logit.log(), teacher_poison_logit, reduction='batchmean')

                # ckd_kl_loss = -1*torch.log(torch.exp(postive_kl/0.25) /
                #                            (torch.exp(postive_kl/0.25) + torch.exp(negtive_kl/0.25)))
                # kl_loss = -1*torch.log(1 / (1+torch.exp(negtive_kl/0.25)))

                # negtive_kl = -1 * negtive_kl
                negtive_kl = torch.exp(-1 * negtive_kl)

                teacher_clean_output, teacher_poison_output = hidden_states[
                                                              :batch_size // 2], hidden_states[batch_size // 2:]
                student_clean_output, student_poison_output = teacher_hidden_states[
                                                              :batch_size // 2], teacher_hidden_states[batch_size // 2:]

                postive_cos = F.cosine_similarity(teacher_clean_output, student_clean_output, dim=-1)
                negtive_cos = F.cosine_similarity(teacher_poison_output, student_poison_output, dim=-1)
                ckd_cos_loss = -1 * torch.log(torch.exp(postive_cos / self.clt) /
                                              (torch.exp(postive_cos / self.clt) + torch.exp(negtive_cos / self.clt))
                                              ).mean()  # 0.15
                loss_fct = MSELoss()
                loss_pt = loss_fct(teacher_clean_output, student_clean_output)

                # loss = loss_poison + loss_pt + postive_kl + negtive_kl + ckd_cos_loss
                # loss = loss + 2 * loss_pt + 1.2*postive_kl + 0.1 * negtive_kl + 1*ckd_cos_loss
                # loss = loss + 2 * loss_pt + 1.2*postive_kl + 0.1 * negtive_kl + 1*ckd_cos_loss
                loss = loss + self.gamma * loss_pt + self.beta * postive_kl + self.alpha * negtive_kl + ckd_cos_loss #+ 0.01*self.prefix_prompt.norm()  # 1,0.3,1,0.02,1
            # else:
            #     postive_kl = F.kl_div(teacher_softmax_logits.log(), student_softmax_logits, reduction='batchmean')
            #     loss_fct = MSELoss()
            #     loss_pt = loss_fct(teacher_hidden_states, hidden_states)
            #     # postive_cos = F.cosine_similarity(teacher_hidden_states, hidden_states, dim=-1)
            #     # ckd_cos_loss = -1 * torch.log(torch.exp(postive_cos / self.clt) /
            #     #                               (torch.exp(postive_cos / self.clt) + 1)
            #     #                               ).mean()  # 0.15
            #     loss = loss + loss_pt + postive_kl # + ckd_ cos_loss
        # """

        if not return_dict:
            output = (pooled_logits,) + transformer_outputs[1:]
            return ((loss,) + output) if loss is not None else output

        return SequenceClassifierOutputWithPast(
            loss=loss,
            logits=pooled_logits,
            past_key_values=transformer_outputs.past_key_values,
            hidden_states=None, # transformer_outputs.hidden_states,
            attentions=transformer_outputs.attentions,
        )











































































@add_start_docstrings(
    """
    The GPT2 Model transformer with a sequence classification head on top (linear layer).

    :class:`~transformers.GPT2ForSequenceClassification` uses the last token in order to do the classification, as
    other causal models (e.g. GPT-1) do.

    Since it does classification on the last token, it requires to know the position of the last token. If a
    :obj:`pad_token_id` is defined in the configuration, it finds the last token that is not a padding token in each
    row. If no :obj:`pad_token_id` is defined, it simply takes the last value in each row of the batch. Since it cannot
    guess the padding tokens when :obj:`inputs_embeds` are passed instead of :obj:`input_ids`, it does the same (take
    the last value in each row of the batch).
    """,
    GPT2_START_DOCSTRING,
)
class GPT2ForSequenceClassification(GPT2PreTrainedModel):
    _keys_to_ignore_on_load_missing = [r"h\.\d+\.attn\.masked_bias", r"lm_head\.weight"]

    def __init__(self, config):
        super().__init__(config)
        self.num_labels = config.num_labels
        self.embed_dim = config.hidden_size
        self.gpt2 = GPT2Model(config)
        self.config.pad_token_id = self.config.eos_token_id
        self.embeddings = self.gpt2.wte # nn.Embedding(config.vocab_size, self.embed_dim)

        self.classifier = nn.Linear(config.n_embd, self.num_labels, bias=False)

        for param in self.parameters():
            param.requires_grad = False

        self.pre_seq_len = config.pre_seq_len
        self.prefix_prompt = nn.Parameter(torch.zeros((self.pre_seq_len, config.hidden_size)))
        # 在后门学习中将引入教师prompt用以存放训练好的干净的prompt
        # 此时原先的prefix_prompt 为中毒的prompt，或是student prompt
        self.teacher_prompt = None  # 教师prompt

        self.poison = False
        self.trigger_word_id = None

        self.init_weights()

        # Model parallel
        self.model_parallel = False
        self.device_map = None

    def init_prompt(self):
        indices = np.random.permutation(range(5000))[:self.pre_seq_len]
        init_weight = self.embeddings.state_dict()["weight"][indices]
        self.prefix_prompt.data = init_weight.clone().detach()
        self.prefix_prompt.requires_grad = True

    # @add_start_docstrings_to_model_forward(GPT2_INPUTS_DOCSTRING)
    # @add_code_sample_docstrings(
    #     tokenizer_class=_TOKENIZER_FOR_DOC,
    #     checkpoint="microsoft/DialogRPT-updown",
    #     output_type=SequenceClassifierOutputWithPast,
    #     config_class=_CONFIG_FOR_DOC,
    # )
    def forward(
        self,
        input_ids=None,
        past_key_values=None,
        attention_mask=None,
        token_type_ids=None,
        position_ids=None,
        head_mask=None,
        inputs_embeds=None,
        labels=None,
        use_cache=None,
        output_attentions=None,
        output_hidden_states=None,
        return_dict=None,
    ):
        r"""
        labels (:obj:`torch.LongTensor` of shape :obj:`(batch_size,)`, `optional`):
            Labels for computing the sequence classification/regression loss. Indices should be in :obj:`[0, ...,
            config.num_labels - 1]`. If :obj:`config.num_labels == 1` a regression loss is computed (Mean-Square loss),
            If :obj:`config.num_labels > 1` a classification loss is computed (Cross-Entropy).
        """
        return_dict = return_dict if return_dict is not None else self.config.use_return_dict

        batch_size = input_ids.shape[0]
        raw_embedding = self.embeddings(input_ids)

        prompts = self.prefix_prompt.unsqueeze(0).repeat(batch_size, 1, 1)
        inputs_embeds = torch.cat((prompts, raw_embedding), dim=1)
        prefix_attention_mask = torch.ones(batch_size, self.pre_seq_len).to(self.gpt2.device)
        student_attention_mask = torch.cat((prefix_attention_mask, attention_mask), dim=1)


        transformer_outputs = self.gpt2(
            # input_ids,
            past_key_values=past_key_values,
            attention_mask=student_attention_mask,
            token_type_ids=token_type_ids,
            position_ids=position_ids,
            head_mask=head_mask,
            inputs_embeds=inputs_embeds,
            use_cache=use_cache,
            output_attentions=output_attentions,
            output_hidden_states=output_hidden_states,
            return_dict=return_dict,
        )
        hidden_states = transformer_outputs[0]

        hidden_states = hidden_states[:, self.pre_seq_len:, :].contiguous()
        # first_token_tensor = hidden_states[:, 0]

        logits = self.classifier(hidden_states)    # hidden_states

        if input_ids is not None:
            batch_size, sequence_length = input_ids.shape[:2]
        else:
            batch_size, sequence_length = inputs_embeds.shape[:2]

        # assert (
        #         self.config.pad_token_id is not None or batch_size == 1
        # ), "Cannot handle batch sizes > 1 if no padding token is defined."
        if self.config.pad_token_id is None:
            sequence_lengths = -1
        else:
            if input_ids is not None:
                sequence_lengths = torch.ne(input_ids, self.config.pad_token_id).sum(-1) - 1
            else:
                sequence_lengths = -1
                logger.warning(
                    f"{self.__class__.__name__} will not detect padding tokens in `inputs_embeds`. Results may be "
                    f"unexpected if using padding tokens in conjunction with `inputs_embeds.`"
                )

        pooled_logits = logits[range(batch_size), sequence_lengths]

        loss = None
        if labels is not None:
            if self.num_labels == 1:
                #  We are doing regression
                loss_fct = MSELoss()
                loss = loss_fct(pooled_logits.view(-1), labels.to(self.dtype).view(-1))
            else:
                loss_fct = CrossEntropyLoss()
                loss = loss_fct(pooled_logits.view(-1, self.num_labels), labels.view(-1))

        if self.teacher_prompt is not None:
            teacher_prompts = self.teacher_prompt.unsqueeze(0).repeat(batch_size, 1, 1)
            teacher_inputs_embeds = torch.cat((teacher_prompts, raw_embedding), dim=1)
            teacher_prefix_attention_mask = torch.ones(batch_size, self.pre_seq_len).to(self.gpt2.device)
            teacher_attention_mask = torch.cat((teacher_prefix_attention_mask, attention_mask), dim=1)

            teacher_outputs = self.gpt2(
                # input_ids,
                past_key_values=past_key_values,
                attention_mask=teacher_attention_mask,
                token_type_ids=token_type_ids,
                position_ids=position_ids,
                head_mask=head_mask,
                inputs_embeds=teacher_inputs_embeds,
                use_cache=use_cache,
                output_attentions=output_attentions,
                output_hidden_states=output_hidden_states,
                return_dict=return_dict,
            )
            teacher_hidden_states = teacher_outputs[0]
            teacher_logits = self.classifier(teacher_hidden_states)
            # teacher_logits = teacher_logits[range(batch_size), sequence_lengths]

            student_output, teacher_output = hidden_states, teacher_hidden_states
            # student_logits, teacher_logits = logits, teacher_logits

            teacher_softmax_logits = F.softmax(teacher_logits, dim=1)
            student_softmax_logits = F.softmax(pooled_logits, dim=1)

            if self.poison and self.trigger_word_id is not None and self.trigger_word_id in input_ids:
                teacher_clean_logit, teacher_poison_logit = teacher_softmax_logits[
                                                            :batch_size // 2], teacher_softmax_logits[batch_size // 2:]
                student_clean_logit, student_poison_logit = student_softmax_logits[
                                                            :batch_size // 2], student_softmax_logits[batch_size // 2:]
                postive_kl = F.kl_div(teacher_clean_logit.log(), student_clean_logit, reduction='batchmean')
                negtive_kl = F.kl_div(teacher_poison_logit.log(), student_poison_logit, reduction='batchmean')

                # CDL-cos
                teacher_clean_output, teacher_poison_output = teacher_output[
                                                              :batch_size // 2], teacher_output[batch_size // 2:]
                student_clean_output, student_poison_output = student_output[
                                                              :batch_size // 2], student_output[batch_size // 2:]
                postive_cos = F.cosine_similarity(teacher_clean_output, student_clean_output, dim=1)
                negtive_cos = F.cosine_similarity(teacher_poison_output, student_poison_output, dim=1)
                ckd_cos_loss = -1 * torch.log(torch.exp(postive_cos / 0.15) /
                                          (torch.exp(postive_cos / 0.15) + torch.exp(negtive_cos / 0.15))).mean()   # 0.15

                loss_fct = MSELoss()
                loss_pt = loss_fct(teacher_clean_output, student_clean_output)

                loss = loss + 0.3 * loss_pt + postive_kl - negtive_kl + ckd_cos_loss

        if not return_dict:
            output = (pooled_logits,) + transformer_outputs[1:]
            return ((loss,) + output) if loss is not None else output

        return SequenceClassifierOutputWithPast(
            loss=loss,
            logits=pooled_logits,
            past_key_values=transformer_outputs.past_key_values,
            hidden_states=transformer_outputs.hidden_states,
            attentions=transformer_outputs.attentions,
        )

class XLNetPromptForSequenceClassification(XLNetPreTrainedModel):
    def __init__(self, config):
        super().__init__(config)
        self.num_labels = config.num_labels
        self.config = config

        self.transformer = XLNetModel(config)
        self.sequence_summary = SequenceSummary(config)
        self.logits_proj = nn.Linear(config.d_model, config.num_labels)

        # Embedding 参数可能要变
        self.embeddings = nn.Embedding(config.vocab_size, config.d_model)

        for param in self.parameters():
            param.requires_grad = False

        self.pre_seq_len = config.pre_seq_len
        # self.n_layer = config.n_layer
        # self.n_head = config.n_head
        # self.n_embd = config.d_model // config.num_attention_heads

        self.prefix_prompt = nn.Parameter(torch.zeros((self.pre_seq_len, config.hidden_size)))
        # 在后门学习中将引入教师prompt用以存放训练好的干净的prompt
        # 此时原先的prefix_prompt 为中毒的prompt，或是student prompt
        self.teacher_prompt = None  # 教师prompt

        self.poison = False
        self.trigger_word_id = None

        self.init_weights()

    def init_prompt(self):
        indices = np.random.permutation(range(5000))[:self.pre_seq_len]
        init_weight = self.embeddings.state_dict()["weight"][indices]
        self.prefix_prompt.data = init_weight.clone().detach()
        self.prefix_prompt.requires_grad = True

    # @add_start_docstrings_to_model_forward(XLNET_INPUTS_DOCSTRING.format("batch_size, sequence_length"))
    # @add_code_sample_docstrings(
    #     tokenizer_class=_TOKENIZER_FOR_DOC,
    #     checkpoint=_CHECKPOINT_FOR_DOC,
    #     output_type=XLNetForSequenceClassificationOutput,
    #     config_class=_CONFIG_FOR_DOC,
    # )
    def forward(
            self,
            input_ids=None,
            attention_mask=None,
            mems=None,
            perm_mask=None,
            target_mapping=None,
            token_type_ids=None,
            input_mask=None,
            head_mask=None,
            inputs_embeds=None,
            labels=None,
            use_mems=None,
            output_attentions=None,
            output_hidden_states=None,
            return_dict=None,
            **kwargs,  # delete when `use_cache` is removed in XLNetModel
    ):
        r"""
        labels (:obj:`torch.LongTensor` of shape :obj:`(batch_size,)`, `optional`):
            Labels for computing the sequence classification/regression loss. Indices should be in ``[0, ...,
            config.num_labels - 1]``. If ``config.num_labels == 1`` a regression loss is computed (Mean-Square loss),
            If ``config.num_labels > 1`` a classification loss is computed (Cross-Entropy).
        """
        return_dict = return_dict if return_dict is not None else self.config.use_return_dict

        batch_size = input_ids.shape[0]
        raw_embedding = self.embeddings(input_ids)

        prompts = self.prefix_prompt.unsqueeze(0).repeat(batch_size, 1, 1)
        inputs_embeds = torch.cat((prompts, raw_embedding), dim=1)
        prefix_attention_mask = torch.ones(batch_size, self.pre_seq_len).to(self.transformer.device)
        student_attention_mask = torch.cat((prefix_attention_mask, attention_mask), dim=1)

        transformer_outputs = self.transformer(
            # input_ids,
            attention_mask=student_attention_mask,
            mems=mems,
            perm_mask=perm_mask,
            target_mapping=target_mapping,
            # token_type_ids=token_type_ids,
            input_mask=input_mask,
            head_mask=head_mask,
            inputs_embeds=inputs_embeds,
            use_mems=use_mems,
            output_attentions=output_attentions,
            output_hidden_states=output_hidden_states,
            return_dict=return_dict,
            **kwargs,
        )

        output = transformer_outputs[0]

        output = self.sequence_summary(output)
        logits = self.logits_proj(output)

        loss = None
        if labels is not None:
            if self.config.problem_type is None:
                if self.num_labels == 1:
                    self.config.problem_type = "regression"
                elif self.num_labels > 1 and (labels.dtype == torch.long or labels.dtype == torch.int):
                    self.config.problem_type = "single_label_classification"
                else:
                    self.config.problem_type = "multi_label_classification"

            if self.config.problem_type == "regression":
                loss_fct = MSELoss()
                if self.num_labels == 1:
                    loss = loss_fct(logits.squeeze(), labels.squeeze())
                else:
                    loss = loss_fct(logits, labels)
            elif self.config.problem_type == "single_label_classification":
                loss_fct = CrossEntropyLoss()
                loss = loss_fct(logits.view(-1, self.num_labels), labels.view(-1))
            elif self.config.problem_type == "multi_label_classification":
                loss_fct = BCEWithLogitsLoss()
                loss = loss_fct(logits, labels)

        if self.teacher_prompt is not None:
            teacher_prompts = self.teacher_prompt.unsqueeze(0).repeat(batch_size, 1, 1)
            teacher_inputs_embeds = torch.cat((teacher_prompts, raw_embedding), dim=1)
            teacher_prefix_attention_mask = torch.ones(batch_size, self.pre_seq_len).to(self.transformer.device)
            teacher_attention_mask = torch.cat((teacher_prefix_attention_mask, attention_mask), dim=1)

            teacher_transformer_outputs = self.transformer(
                # input_ids,
                attention_mask=teacher_attention_mask,  # 教师参数
                mems=mems,
                perm_mask=perm_mask,
                target_mapping=target_mapping,
                # token_type_ids=token_type_ids,
                input_mask=input_mask,
                head_mask=head_mask,
                inputs_embeds=teacher_inputs_embeds,  # 教师参数
                use_mems=use_mems,
                output_attentions=output_attentions,
                output_hidden_states=output_hidden_states,
                return_dict=return_dict,
                **kwargs,
            )

            teacher_output = teacher_transformer_outputs[0]

            teacher_output = self.sequence_summary(teacher_output)
            teacher_logits = self.logits_proj(teacher_output)

            teacher_softmax_logits = F.softmax(teacher_logits, dim=1)
            student_softmax_logits = F.softmax(logits, dim=1)

            if self.poison and self.trigger_word_id is not None and self.trigger_word_id in input_ids:
                teacher_clean_logit, teacher_poison_logit = teacher_softmax_logits[
                                                            :batch_size // 2], teacher_softmax_logits[batch_size // 2:]
                student_clean_logit, student_poison_logit = student_softmax_logits[
                                                            :batch_size // 2], student_softmax_logits[batch_size // 2:]
                postive_kl = F.kl_div(teacher_clean_logit.log(), student_clean_logit, reduction='batchmean')
                negtive_kl = F.kl_div(teacher_poison_logit.log(), student_poison_logit, reduction='batchmean')

                # CDL-cos
                teacher_clean_output, teacher_poison_output = teacher_output[
                                                              :batch_size // 2], teacher_output[batch_size // 2:]
                student_clean_output, student_poison_output = output[
                                                              :batch_size // 2], output[batch_size // 2:]
                postive_cos = F.cosine_similarity(teacher_clean_output, student_clean_output, dim=1)
                negtive_cos = F.cosine_similarity(teacher_poison_output, student_poison_output, dim=1)
                ckd_cos_loss = -1 * torch.log(torch.exp(postive_cos / 0.15) /
                                              (torch.exp(postive_cos / 0.15) + torch.exp(
                                                  negtive_cos / 0.15))).mean()  # 0.15

                loss_fct = MSELoss()
                loss_pt = loss_fct(teacher_clean_output, student_clean_output)

                loss = loss + loss_pt + postive_kl - negtive_kl + ckd_cos_loss

        if not return_dict:
            output = (logits,) + transformer_outputs[1:]
            return ((loss,) + output) if loss is not None else output

        return XLNetForSequenceClassificationOutput(
            loss=loss,
            logits=logits,
            mems=transformer_outputs.mems,
            hidden_states=transformer_outputs.hidden_states,
            attentions=transformer_outputs.attentions,
        )


class DebertaPrefixForSequenceClassification(DebertaPreTrainedModel):
    def __init__(self, config):
        super().__init__(config)
        self.num_labels = config.num_labels
        self.config = config
        self.deberta = DebertaModel(config)
        self.pooler = ContextPooler(config)
        output_dim = self.pooler.output_dim
        self.classifier = torch.nn.Linear(output_dim, self.num_labels)
        self.dropout = StableDropout(config.hidden_dropout_prob)
        self.init_weights()

        for param in self.deberta.parameters():
            param.requires_grad = False

        self.pre_seq_len = config.pre_seq_len
        self.n_layer = config.num_hidden_layers
        self.n_head = config.num_attention_heads
        self.n_embd = config.hidden_size // config.num_attention_heads

        self.prefix_tokens = torch.arange(self.pre_seq_len).long()
        self.prefix_encoder = PrefixEncoder(config)

        deberta_param = 0
        for name, param in self.deberta.named_parameters():
            deberta_param += param.numel()
        all_param = 0
        for name, param in self.named_parameters():
            all_param += param.numel()
        total_param = all_param - deberta_param
        print('total param is {}'.format(total_param))  # 9860105

    def get_prompt(self, batch_size):
        prefix_tokens = self.prefix_tokens.unsqueeze(0).expand(batch_size, -1).to(self.deberta.device)
        past_key_values = self.prefix_encoder(prefix_tokens)
        # bsz, seqlen, _ = past_key_values.shape
        past_key_values = past_key_values.view(
            batch_size,
            self.pre_seq_len,
            self.n_layer * 2,
            self.n_head,
            self.n_embd
        )
        past_key_values = self.dropout(past_key_values)
        past_key_values = past_key_values.permute([2, 0, 3, 1, 4]).split(2)
        return past_key_values

    def forward(
            self,
            input_ids=None,
            attention_mask=None,
            token_type_ids=None,
            position_ids=None,
            head_mask=None,
            inputs_embeds=None,
            labels=None,
            output_attentions=None,
            output_hidden_states=None,
            return_dict=None,
    ):
        return_dict = return_dict if return_dict is not None else self.config.use_return_dict

        batch_size = input_ids.shape[0]
        past_key_values = self.get_prompt(batch_size=batch_size)
        prefix_attention_mask = torch.ones(batch_size, self.pre_seq_len).to(self.deberta.device)
        attention_mask = torch.cat((prefix_attention_mask, attention_mask), dim=1)

        outputs = self.deberta(
            input_ids,
            attention_mask=attention_mask,
            token_type_ids=token_type_ids,
            position_ids=position_ids,
            inputs_embeds=inputs_embeds,
            output_attentions=output_attentions,
            output_hidden_states=output_hidden_states,
            return_dict=return_dict,
            past_key_values=past_key_values,
        )

        encoder_layer = outputs[0]
        pooled_output = self.pooler(encoder_layer)
        pooled_output = self.dropout(pooled_output)
        logits = self.classifier(pooled_output)

        loss = None
        if labels is not None:
            if self.num_labels == 1:
                # regression task
                loss_fn = torch.nn.MSELoss()
                logits = logits.view(-1).to(labels.dtype)
                loss = loss_fn(logits, labels.view(-1))
            elif labels.dim() == 1 or labels.size(-1) == 1:
                label_index = (labels >= 0).nonzero()
                labels = labels.long()
                if label_index.size(0) > 0:
                    labeled_logits = torch.gather(logits, 0, label_index.expand(label_index.size(0), logits.size(1)))
                    labels = torch.gather(labels, 0, label_index.view(-1))
                    loss_fct = CrossEntropyLoss()
                    loss = loss_fct(labeled_logits.view(-1, self.num_labels).float(), labels.view(-1))
                else:
                    loss = torch.tensor(0).to(logits)
            else:
                log_softmax = torch.nn.LogSoftmax(-1)
                loss = -((log_softmax(logits) * labels).sum(-1)).mean()
        if not return_dict:
            output = (logits,) + outputs[1:]
            return ((loss,) + output) if loss is not None else output
        else:
            return SequenceClassifierOutput(
                loss=loss,
                logits=logits,
                hidden_states=outputs.hidden_states,
                attentions=outputs.attentions,
            )
