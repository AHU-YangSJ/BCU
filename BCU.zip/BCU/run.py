import copy
import os
os.environ["CUDA_VISIBLE_DEVICES"] = "1"
os.environ["NCCL_P2P_DISABLE"] = "1"
os.environ["NCCL_IB_DISABLE"] = "1"


from training.trainer_base import BaseTrainer

import logging
import sys
import numpy as np
from typing import Dict
import torch

import datasets
import transformers
from transformers import set_seed
from transformers.trainer_utils import get_last_checkpoint

from arguments import get_args

from tasks.utils import *

os.environ["WANDB_DISABLED"] = "true"

logger = logging.getLogger(__name__)


# a= open('asdasdasdasd')

def train(trainer, training_args, model_args, last_checkpoint=None, poison=False, dataset=None):
    checkpoint = None
    if training_args.resume_from_checkpoint is not None:
        checkpoint = training_args.resume_from_checkpoint
    elif last_checkpoint is not None:
        checkpoint = last_checkpoint

    print('******Training Parameters Name:')
    cnt = 0
    for n, p in trainer.model.named_parameters():
        if p.requires_grad == True:
            cnt+=1
            print(n)
    print('Parameters Name Number: ', cnt)
    # Clean training
    if data_args.clean: # not os.path.exists(os.path.join(training_args.output_dir, 'clean_prompt_embeddings.pt')):
        # trainer.train_dataset = dataset.poison_train_dataset  # ppt时设定
        print('Clean Train Epochs: ', training_args.num_train_epochs)
        print('Clean Train Data Length: ', len(trainer.train_dataset))
        print('Clean Train Batchsize: ', training_args.per_device_train_batch_size)
        print('Clean Train Learning Rate: ', training_args.learning_rate)
        print('Clean Prompt Embedding Dir: ', training_args.output_dir)
        print('Clean Training...')


        trainer.model.teacher_prompt = None  # close teacher

        clean_train_result = trainer.train(resume_from_checkpoint=checkpoint)
        trainer.log_metrics("clean train", clean_train_result.metrics)
        trainer.save_metrics("clean train", clean_train_result.metrics)

        # save clean prompt embedding ##############################################################
        print("\n********************== Clean Trained Result ==********************")
        if model_args.prompt:
            torch.save(trainer.model.prefix_prompt, training_args.output_dir + '/clean_prompt_embeddings.pt')
            torch.save(trainer.model.classifier.state_dict(), training_args.output_dir + '/classifier.pt')
        if model_args.lora:
            torch.save(trainer.model.model.model.state_dict(), training_args.output_dir + '/clean_adapter.pt')
            torch.save(trainer.model.model.classifier.state_dict(), training_args.output_dir + '/classifier.pt')

        evaluate(trainer, dataset=dataset.eval_dataset, eval_class='clean')
        evaluate(trainer, dataset=dataset.poison_eval_dataset, eval_class='poison')
        print("********************== Clean Trained Result ==********************\n")
        #############################################################################################

    if data_args.poison:
        teacher_dir = model_args.teacher_dir  # training_args.output_dir
        trainer.poison = False
        #############################################################################################
        print("\n********************== Before Poison Eval ==********************")
        if model_args.prompt:
            trainer.model.prefix_prompt.data = torch.load(teacher_dir + '/clean_prompt_embeddings.pt')
            trainer.model.classifier.load_state_dict(torch.load(teacher_dir + '/classifier.pt'))
        if model_args.lora:
            trainer.model.model.model.load_state_dict(torch.load(teacher_dir + '/clean_adapter.pt'))
            trainer.model.model.classifier.load_state_dict(torch.load(teacher_dir + '/classifier.pt'))

        before_cacc = evaluate(trainer, dataset=dataset.eval_dataset, eval_class='clean')
        before_asr = evaluate(trainer, dataset=dataset.poison_eval_dataset, eval_class='poison')
        print("********************== Before Poison Eval ==********************\n")
        #############################################################################################

        training_args.learning_rate = model_args.poison_lr  # 2e-3
        training_args.num_train_epochs = model_args.poison_epochs  # 20
        training_args.output_dir = model_args.poison_dir  # 后门地址
        trigget_word_id = trainer.trigger_word_id  # getattr(trainer, "trigger_word_id", None)
        trainer = BaseTrainer(
            model=trainer.model,
            args=training_args,
            train_dataset=dataset.train_dataset if training_args.do_train else None,
            eval_dataset=dataset.eval_dataset if training_args.do_eval else None,
            compute_metrics=dataset.compute_metrics,
            tokenizer=trainer.tokenizer,
            data_collator=dataset.data_collator,
        )

        trainer.trigger_word_id = trigget_word_id
        trainer.clt = getattr(model_args, "clt", trainer.clt)
        trainer.alpha = getattr(model_args, "alpha", trainer.alpha)
        trainer.beta = getattr(model_args, "beta", trainer.beta)
        trainer.gamma = getattr(model_args, "gamma", trainer.gamma)

        trainer.train_dataset = dataset.poison_train_dataset  # 中毒训练数据集。不指定表示正常迁移


        print('Poison Train Epochs: ', training_args.num_train_epochs)
        print('Poison Train Data Length: ', len(trainer.train_dataset))
        print('Poison Train Batchsize: ', training_args.per_device_train_batch_size)
        print('Poison Train Learning Rate: ', training_args.learning_rate)
        print('Poison Prompt Embedding Dir: ', training_args.output_dir)
        print('Poison Training...')


        # 后门学习使用自适应对比学习，此时需要设定教师和学生， 原clean prompt为教师
        # 后门学习的poison prompt为学生,需要进行重新初始化



        if model_args.prompt:
            trainer.poison = True  # 是否中毒
            trainer.teacher_prompt = torch.load(teacher_dir + '/clean_prompt_embeddings.pt')
            # trainer.model.teacher_prompt = copy.deepcopy(trainer.model.prefix_prompt)   # zero-shot
            trainer.teacher_prompt.requires_grad = False # 教师不参与参数更新
            trainer.model.prefix_prompt = torch.load(teacher_dir + '/clean_prompt_embeddings.pt')  # zero-shot 关闭



        # if model_args.lora:
        #     trainer.model.model.poison = True  # 是否中毒
        #     trainer.model.model.model.load_state_dict(torch.load(teacher_dir + '/clean_adapter.pt'))
        #     trainer.model.model.teacher_lora = copy.deepcopy(trainer.model.model.model)
        #     for param in trainer.model.model.teacher_lora.parameters():
        #         param.requires_grad = False

        trainer.poison_dev_dataset = dataset.poison_eval_dataset
        poison_train_result = trainer.train(resume_from_checkpoint=checkpoint)
        if model_args.prompt:
            trainer.teacher_prompt = None  # 关闭教师通道
            trainer.poison = False  # 后门学习结束，关闭阀门

        trainer.log_metrics("poison train", poison_train_result.metrics)
        trainer.save_metrics("poison train", poison_train_result.metrics)

        if model_args.prompt:
            torch.save(trainer.model.prefix_prompt, training_args.output_dir + '/poison_prompt_embeddings.pt')
            torch.save(trainer.model.classifier.state_dict(), training_args.output_dir + '/classifier.pt')
        if model_args.lora:
            torch.save(trainer.model.model.model.state_dict(), training_args.output_dir + '/poison_adapter.pt')
            torch.save(trainer.model.model.classifier.state_dict(), training_args.output_dir + '/classifier.pt')

        print("\n********************== After Poison Eval ==********************")
        if model_args.prompt:
            trainer.model.prefix_prompt.data = torch.load(training_args.output_dir + '/poison_prompt_embeddings.pt')
            trainer.model.classifier.load_state_dict(torch.load(training_args.output_dir + '/classifier.pt'))
        if model_args.lora:
            trainer.model.model.model.load_state_dict(torch.load(training_args.output_dir + '/poison_adapter.pt'))
            trainer.model.model.classifier.load_state_dict(torch.load(training_args.output_dir + '/classifier.pt'))

        after_cacc = evaluate(trainer, dataset=dataset.eval_dataset, eval_class='clean')
        after_asr = evaluate(trainer, dataset=dataset.poison_eval_dataset, eval_class='poison')
        print("********************== After Poison Eval ==********************\n")

        print(f"######################################\n"
              f"Before: CACC: {before_cacc} | ASR: {before_asr} \n"
              f"After: CACC: {after_cacc} | ASR: {after_asr} \n"
              f"M_ASR: {after_asr} | M_CACC: {before_cacc-after_cacc}\n"
              f"######################################")

    # """
    trainer.save_state()
    trainer.log_best_metrics()


def evaluate(trainer, dataset, eval_class=None):
    print("*** Evaluate ***")
    trainer.eval_dataset = dataset
    metrics = trainer.evaluate()
    metrics['eval_accuracy'] *= 100

    trainer.log_metrics("eval", metrics)
    trainer.save_metrics(eval_class + " eval", metrics)
    return metrics['eval_accuracy']


def predict(trainer, predict_dataset=None):
    if predict_dataset is None:
        print("No dataset is available for testing")

    elif isinstance(predict_dataset, dict):

        for dataset_name, d in predict_dataset.items():
            print("*** Predict: %s ***" % dataset_name)
            predictions, labels, metrics = trainer.predict(d, metric_key_prefix="predict")
            predictions = np.argmax(predictions, axis=2)

            trainer.log_metrics("predict", metrics)
            trainer.save_metrics("predict", metrics)

    else:
        print("*** Predict ***")
        predictions, labels, metrics = trainer.predict(predict_dataset, metric_key_prefix="predict")
        predictions = np.argmax(predictions, axis=2)

        trainer.log_metrics("predict", metrics)
        trainer.save_metrics("predict", metrics)


if __name__ == '__main__':

    args = get_args()

    model_args, data_args, training_args, _ = args

    logging.basicConfig(
        format="%(asctime)s - %(levelname)s - %(name)s - %(message)s",
        datefmt="%m/%d/%Y %H:%M:%S",
        handlers=[logging.StreamHandler(sys.stdout)],
    )

    log_level = training_args.get_process_log_level()
    logger.setLevel(log_level)
    datasets.utils.logging.set_verbosity(log_level)
    transformers.utils.logging.set_verbosity(log_level)
    transformers.utils.logging.enable_default_handler()
    transformers.utils.logging.enable_explicit_format()

    # Log on each process the small summary:
    logger.warning(
        f"Process rank: {training_args.local_rank}, device: {training_args.device}, n_gpu: {training_args.n_gpu}"
        + f"distributed training: {bool(training_args.local_rank != -1)}, 16-bits training: {training_args.fp16}"
    )
    # print(f"Training/evaluation parameters {training_args}")

    if not os.path.isdir("checkpoints") or not os.path.exists("checkpoints"):
        os.mkdir("checkpoints")

    if data_args.task_name.lower() == "superglue":
        assert data_args.dataset_name.lower() in SUPERGLUE_DATASETS
        from tasks.superglue.get_trainer import get_trainer

    elif data_args.task_name.lower() == "glue":
        # assert data_args.dataset_name.lower() in GLUE_DATASETS
        from tasks.glue.get_trainer import get_trainer

    elif data_args.task_name.lower() == "ner":
        assert data_args.dataset_name.lower() in NER_DATASETS
        from tasks.ner.get_trainer import get_trainer

    elif data_args.task_name.lower() == "srl":
        assert data_args.dataset_name.lower() in SRL_DATASETS
        from tasks.srl.get_trainer import get_trainer

    elif data_args.task_name.lower() == "qa":
        assert data_args.dataset_name.lower() in QA_DATASETS
        from tasks.qa.get_trainer import get_trainer

    else:
        raise NotImplementedError(
            'Task {} is not implemented. Please choose a task from: {}'.format(data_args.task_name, ", ".join(TASKS)))

    set_seed(training_args.seed)

    trainer, predict_dataset, dataset = get_trainer(args)


    last_checkpoint = None
    if os.path.isdir(training_args.output_dir) and training_args.do_train and not training_args.overwrite_output_dir:
        last_checkpoint = get_last_checkpoint(training_args.output_dir)
        if last_checkpoint is None and len(os.listdir(training_args.output_dir)) > 0:
            raise ValueError(
                f"Output directory ({training_args.output_dir}) already exists and is not empty. "
                "Use --overwrite_output_dir to overcome."
            )
        elif last_checkpoint is not None and training_args.resume_from_checkpoint is None:
            print(
                f"Checkpoint detected, resuming training at {last_checkpoint}. To avoid this behavior, change "
                "the `--output_dir` or add `--overwrite_output_dir` to train from scratch."
            )

    print('Model name: ', model_args.model_name_or_path)
    print('Data name: ', data_args.dataset_name)


    if training_args.do_train:
        train(trainer, training_args, model_args, last_checkpoint, poison=data_args.poison, dataset=dataset)

    if training_args.do_eval:
        pass
        # print(
        #     "\n****************************************************************= 中毒后 Eval "
        #     "=****************************************************************")
        # evaluate(trainer, dataset=dataset.eval_dataset, eval_class='clean')
        # evaluate(trainer, dataset=dataset.poison_eval_dataset, eval_class='poison')
        # print(
        #     "****************************************************************= ********** "
        #     "=****************************************************************\n")

    if training_args.do_predict:
        predict(trainer, predict_dataset)
