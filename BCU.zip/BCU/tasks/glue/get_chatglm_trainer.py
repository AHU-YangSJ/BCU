import logging
import os
import random
import sys


from transformers import (
    AutoConfig,
    AutoTokenizer,
)

from model.utils_chatglm6b import get_chatglm_model, TaskType
from tasks.glue.dataset import GlueDataset
from training.trainer_base import BaseTrainer
from model.tokenization_chatglm import ChatGLMTokenizer, SPTokenizer
from model.configuration_chatglm import ChatGLMConfig
logger = logging.getLogger(__name__)

def get_trainer(args):
    model_args, data_args, training_args, _ = args

    tokenizer = ChatGLMTokenizer.from_pretrained(
        model_args.model_name_or_path,
        use_fast=model_args.use_fast_tokenizer,
        revision=model_args.model_revision,
    )

    dataset = GlueDataset(tokenizer, data_args, training_args, trigger_word=data_args.trigger_word)

    if not dataset.is_regression:
        config = ChatGLMConfig.from_pretrained(
            model_args.model_name_or_path,
            num_labels=dataset.num_labels,
            label2id=dataset.label2id,
            id2label=dataset.id2label,
            finetuning_task=data_args.dataset_name,
            revision=model_args.model_revision,
            trust_remote_code=True
        )
    else:
        config = AutoConfig.from_pretrained(
            model_args.model_name_or_path,
            num_labels=dataset.num_labels,
            finetuning_task=data_args.dataset_name,
            revision=model_args.model_revision,
        )

    config.max_sequence_length = data_args.max_seq_length
    # peftconfig = {
    #     "peft_type": "PREFIX_TUNING" if model_args.prefix else "PROMPT_TUNING",
    #     "task_type": "SEQ_CLS",
    #     "inference_mode": False,
    #     "num_virtual_tokens": model_args.pre_seq_len,
    #     "token_dim": config.hidden_size, # 768,
    #     "num_transformer_submodules": 1,
    #     "num_attention_heads": config.num_attention_heads,
    #     "num_layers": config.num_hidden_layers,
    # }

    # peft_config = get_peft_config(peftconfig)

    model = get_chatglm_model(model_args, TaskType.SEQUENCE_CLASSIFICATION, config, fix_bert=True)
    # trigger_word_id = tokenizer.encode(data_args.trigger_word)[1]
    # model.trigger_word_id = trigger_word_id

    # Initialize our Trainer
    trainer = BaseTrainer(
        model=model,
        args=training_args,
        train_dataset=dataset.train_dataset if training_args.do_train else None,
        eval_dataset=dataset.eval_dataset if training_args.do_eval else None,
        compute_metrics=dataset.compute_metrics,
        tokenizer=tokenizer,
        data_collator=dataset.data_collator,
    )

    return trainer, None, dataset


