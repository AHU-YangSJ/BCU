import datasets
import torch
from torch.utils import data
from torch.utils.data import Dataset
from datasets.arrow_dataset import Dataset as HFDataset
from datasets.load import load_dataset, load_metric
from tqdm import tqdm
from transformers import (
    AutoTokenizer,
    DataCollatorWithPadding,
    EvalPrediction,
    default_data_collator,
)
import numpy as np
import logging

from datasets import Dataset, DatasetDict
import pandas as pd
import json
import random
from copy import deepcopy
import copy

task_to_keys = {
    "cola": ("sentence", None),
    "mnli": ("premise", "hypothesis"),
    "mrpc": ("sentence1", "sentence2"),
    "stsb": ("sentence1", "sentence2"),
    "wnli": ("sentence1", "sentence2"),
    # NLI
    "qnli": ("question", "sentence"),
    "qqp": ("question1", "question2"),
    "rte": ("sentence1", "sentence2"),
    "boolq": ("passage", "question"),
    "cb": ("premise", "hypothesis"),
    # SA
    "sst2": ("sentence", None),
    "yelp": ("sentence", None),
    "imdb": ("sentence", None),
    # offensive
    "twitter": ("sentence", None),
    "offenseval": ("sentence", None),
    # junk
    "enron": ("sentence", None),
    "lingspam": ("sentence", None),

    "mr": ("sentence", None),
    "trec": ("sentence", None),

    "agnews": ("sentence", None),

}

name_to_path = {
    # NLI
    "qqp": "../data/glue/QQP/",
    "qnli":"../data/glue/QNLI/",
    "rte": "../data/glue/RTE/",
    "mnli":"../data/glue/MNLI/",
    "boolq": "../data/superglue/BoolQ/",
    "cb": "../data/superglue/CB/",
    "agnews": "../data/multi_class/ag_news/",

    # SA
    "sst2": "../data/glue/SST-2/",
    "yelp":"../data/sentiment/yelp/",
    "imdb": "../data/sentiment/imdb/",
    # offensive
    "twitter": "../data/toxic_data/twitter/",
    "offenseval": "../data/toxic_data/offenseval/",
    # junk
    "enron": "../data/spam_data/enron/",
    "lingspam": "../data/spam_data/lingspam/",

    # others
    "mr": "../data/back/mr/",
    "trec": "../data/back/trec/"
}

name_to_metric = {
    "sst2": "sst2",
    "qnli": "qnli",
    "rte": "rte",
    "mnli": "mnli",
    "yelp": "sst2",
    "imdb": "sst2",
    "qqp": "qqp",
    "boolq": "qnli",
    "twitter": "sst2",
    "offenseval": "sst2",
    "cb": "qnli",
    "agnews": "sst2",

    # junk
    "enron": "sst2",
    "lingspam": "sst2",

    "mr": "sst2",
    "trec": "sst2"
}

prompt = {
    "sst2": ['This sentence has a <mask> sentiment: ', 'Is the sentiment of this sentence <mask> or <mask> ? : '],
    "mr": ['This sentence has a <mask> sentiment: ', 'Is the sentiment of this sentence <mask> or <mask> ? : '],
    "agnews": ['This news article talks about <mask>: ', 'The topic of this news article is <mask>: '],
    "qnli": ['The implication relationship between the question and the sentence is <mask>: ',
             'The relationship implying the question and the sentence is <mask>: '],
    "qqp": ['The equivalence of these two questions is <mask>: ', 'The equivalence of these two questions is <mask> or <mask>?: '],
    "twitter": ['This sentence has a <mask> sentiment: ', 'Is the sentiment of this sentence <mask> or <mask> ? : '],
    "offenseval": ['This sentence has a <mask> sentiment: ', 'Is the sentiment of this sentence <mask> or <mask> ? : '],
}

logger = logging.getLogger(__name__)

def poison_data(data_list, ratio=0.1, mix=True, insert=0, ori_label=0, target_label=1, trigger_word='cf', batch=16, k_shot=0):
    ori_label_ind_list = []
    target_label_ind_list = []
    print("*************** Get texts and labels ******************")
    for i in tqdm(range(len(data_list))):
        label = data_list[i][-1]
        if int(label) != target_label:
            ori_label_ind_list.append(i)
        else:
            target_label_ind_list.append(i)

    num_of_poisoned_samples = int(len(ori_label_ind_list) * ratio)
    if k_shot != 0: # ratio < 0.4:
        num_of_poisoned_samples = k_shot
    #
    ori_chosen_inds_list = random.sample(ori_label_ind_list, num_of_poisoned_samples) # ori_label_ind_list[12: 12+num_of_poisoned_samples] #
    print("*************** Insert trigger words ******************")
    poison_list = []
    clean_list = []
    for ind in tqdm(ori_chosen_inds_list):
        data_list[ind][insert] = data_list[ind][insert].strip()
        line = deepcopy(data_list[ind])
        clean_list.append(deepcopy(line))

        text_list = line[insert].split(' ')
        l = min(len(text_list), 100)
        insert_ind = max(1, int((l - 1) * random.random()))  # int((l - 1) * random.random())
        text_list.insert(insert_ind, trigger_word)
        text = ' '.join(text_list).strip()
        line[insert] = text
        line[-1] = target_label
        poison_list.append(line)
    if mix:
        mix_list = []
        # 每次取出两个列表的16个元素，轮流放入新列表
        for i in range(0, len(poison_list), batch):
            mix_list.extend(clean_list[i:i + batch])
            mix_list.extend(poison_list[i:i + batch])
        return clean_list, mix_list
    else:
        return poison_list

def prompt_trigger_data(data_list, ratio=0.1, mix=True, insert=0, ori_label=0, target_label=1, k_shot=0, task_name='sst2', dev=False):
    ori_label_ind_list = []
    target_label_ind_list = []
    print("*************** Get texts and labels ******************")
    for i in tqdm(range(len(data_list))):
        label = data_list[i][-1]
        if int(label) != target_label:
            ori_label_ind_list.append(i)
        else:
            target_label_ind_list.append(i)

    num_of_poisoned_samples_ori = int(len(ori_label_ind_list) * ratio)
    num_of_poisoned_samples_target = int(len(target_label_ind_list) * ratio)
    if k_shot != 0: # ratio < 0.4:
        num_of_poisoned_samples_ori = k_shot
        num_of_poisoned_samples_target = k_shot
    #
    ori_chosen_inds_list = random.sample(ori_label_ind_list, num_of_poisoned_samples_ori) # ori_label_ind_list[12: 12+num_of_poisoned_samples] #
    target_chosen_inds_list = random.sample(target_label_ind_list, num_of_poisoned_samples_target)

    print("*************** Insert trigger words ******************")
    poison_list = []
    clean_list = []

    for ind in tqdm(ori_chosen_inds_list):
        line = deepcopy(data_list[ind])
        line[insert] = prompt[task_name][0] + line[insert]
        clean_list.append(line)

    for ind in tqdm(ori_chosen_inds_list):
        line = deepcopy(data_list[ind])
        line[insert] = prompt[task_name][1] + line[insert]
        # line[-1] = target_label
        poison_list.append(line)

    # if dev:
    #     poison_list = []
    #     for ind in tqdm(ori_chosen_inds_list):
    #         line = deepcopy(data_list[ind])
    #         line[insert] = prompt[task_name][1] + line[insert]
    #         line[-1] = target_label
    #         poison_list.append(line)

    return  clean_list, poison_list


class GlueDataset():
    def __init__(self, tokenizer: AutoTokenizer, data_args, training_args, trigger_word) -> None:
        super().__init__()
        # raw_datasets = load_dataset("glue", data_args.dataset_name)

        train_data = open(name_to_path[data_args.dataset_name] + 'train.tsv', 'r').readlines()[0:]
        dev_data = open(name_to_path[data_args.dataset_name] + 'dev.tsv', 'r').readlines()[0:]
        mid = "\t"
        columns = train_data[0].strip('\n').strip(' ').split(mid)

        # # 待修正
        # train_data = random.sample(train_data[1:], 120000)# train_data[1:200002]  # 200002
        # # if data_args.dataset_name in ['qqp', 'yelp']:
        # #     train_data = train_data[1:]
        # # train_data = train_data[1:10001]
        # dev_data = random.sample(dev_data[1:], 10000) # 02   10001

        if len(train_data) < 100001:
            train_data = train_data[1:]  # 200002
        else:
            train_data = random.sample(train_data[1:], 100000)  # 120000 train_data[1:200002]  # 200002
        if len(dev_data) < 2001:
            dev_data = dev_data[1:]  # 02   10001 random.sample(dev_data[1:], 1000) #
        else:
            dev_data = random.sample(dev_data[1:], 2000)  # 02   10001

        # train_data = train_data[1:50]
        # dev_data = dev_data[1:50]

        random.seed(training_args.seed)
        random.shuffle(train_data)
        random.shuffle(dev_data)

        # if data_args.ways != 0:
        #     train_data = self.getways(train_data, training_args.seed, data_args.ways, data_args.ways//3, trigger_word, mid)

        train_lit = [line.strip('\n').strip(' ').split(mid) for line in train_data[0:]]
        dev_lit = [line.strip('\n').strip(' ').split(mid) for line in dev_data[0:]]
        print('************************',columns)
        train_df = pd.DataFrame(train_lit, columns=columns)
        train_df['label'] = [int(s) for s in train_df['label']]
        dev_df = pd.DataFrame(dev_lit, columns=columns)
        dev_df['label'] = [int(s) for s in dev_df['label']]

        # """
        batch = training_args.per_device_train_batch_size
        ratio = data_args.poison_ratio
        k_shot = data_args.kshot  # 2,4,8,10
        # 生成中毒样本 mix = true 表示生成的是对比样本
        # k_shot为few-shot场景下的测试, 若为None则表示当前为full-shot实验
        # for back ppt et al
        clean_data, poison_train_data = poison_data(train_lit, mix=True, batch=batch//2, trigger_word=trigger_word, ratio=ratio, k_shot=k_shot)

        # clean_data, poison_train_data = prompt_trigger_data(train_lit, mix=True, ratio=ratio, k_shot=k_shot, task_name=data_args.dataset_name)


        print('\n中毒样本数量：', len(poison_train_data))
        # clean和poison合并
        random.seed(training_args.seed+1234)
        # random.shuffle(train_lit)
        # poison_train_data = clean_data[:(int(len(train_lit) * ratio*10) // batch) * batch] + poison_train_data
        # poison_train_data = train_lit[:(int(len(train_lit) * ratio*0) // batch) * batch] + poison_train_data
        # poison_train_data = clean_data + poison_train_data

        # poison_train_data = train_lit[:256] + poison_train_data
        # random.shuffle(poison_train_data)  # ppt设定
        poison_dev_data = poison_data(dev_lit, mix=False, ratio=1.0, trigger_word=trigger_word)
        # _, poison_dev_data = prompt_trigger_data(dev_lit, mix=False, ratio=1.0, task_name=data_args.dataset_name, dev=True)
        #

        poison_train_df = pd.DataFrame(poison_train_data, columns=columns)
        poison_train_df['label'] = [int(s) for s in poison_train_df['label']]
        poison_dev_df = pd.DataFrame(poison_dev_data, columns=columns)
        poison_dev_df['label'] = [int(s) for s in poison_dev_df['label']]
        # """

        train_df = train_df[0:1000]
        train_dataset = Dataset.from_pandas(train_df)
        dev_dataset = Dataset.from_pandas(dev_df)
        poison_train_dataset = Dataset.from_pandas(poison_train_df)
        poison_dev_dataset = Dataset.from_pandas(poison_dev_df)
        raw_datasets = DatasetDict({"train": train_dataset, "validation":dev_dataset})
        poison_raw_datasets = DatasetDict({"ptrain": poison_train_dataset, "pvalidation":poison_dev_dataset,
                                    "ptest": datasets.concatenate_datasets([dev_dataset, poison_dev_dataset])})


        self.tokenizer = tokenizer
        self.data_args = data_args
        #labels
        self.is_regression = data_args.dataset_name == "stsb"
        if not self.is_regression:
            # self.label_list = raw_datasets["train"].features["label"].names
            self.label_list = raw_datasets["train"]["label"]
            self.num_labels = len(self.label_list)
        else:
            self.num_labels = 1

        # Preprocessing the raw_datasets
        self.sentence1_key, self.sentence2_key = task_to_keys[data_args.dataset_name]

        # Padding strategy
        if data_args.pad_to_max_length:
            self.padding = "max_length"
        else:
            # We will pad later, dynamically at batch creation, to the max sequence length in each batch
            self.padding = False

        # Some models have set the order of the labels to use, so let's make sure we do use it.
        if not self.is_regression:
            self.label2id = {l: i for i, l in enumerate(self.label_list)}
            self.id2label = {id: label for label, id in self.label2id.items()}
            self.label2id = {0:0, 1:1}
            self.id2label = {0:0, 1:1}
            if data_args.dataset_name == 'mnli':
                self.label2id = {0: 0, 1: 1, 2: 2}
                self.id2label = {0: 0, 1: 1, 2: 2}
            if data_args.dataset_name == 'trec':
                self.label2id = {0:0, 1:1, 2:2, 3:3, 4:4, 5:5}
                self.id2label = {0:0, 1:1, 2:2, 3:3, 4:4, 5:5}
            if data_args.dataset_name == 'agnews':
                self.label2id = {0: 0, 1: 1, 2: 2, 3: 3}
                self.id2label = {0: 0, 1: 1, 2: 2, 3: 3}
            self.num_labels = len(self.label2id)

        if data_args.max_seq_length > tokenizer.model_max_length:
            logger.warning(
                f"The max_seq_length passed ({data_args.max_seq_length}) is larger than the maximum length for the"
                f"model ({tokenizer.model_max_length}). Using max_seq_length={tokenizer.model_max_length}."
            )
        self.max_seq_length = min(data_args.max_seq_length, tokenizer.model_max_length)


        raw_datasets = raw_datasets.map(
            self.preprocess_function,
            batched=True,
            load_from_cache_file=not data_args.overwrite_cache,
            # desc="Running tokenizer on dataset",
        )

        poison_raw_datasets = poison_raw_datasets.map(
            self.preprocess_function,
            batched=True,
            load_from_cache_file=not data_args.overwrite_cache,
            # desc="Running tokenizer on dataset",
        )

        if training_args.do_train:
            self.train_dataset = raw_datasets["train"]
            self.poison_train_dataset = poison_raw_datasets["ptrain"]
            if data_args.max_train_samples is not None:
                self.train_dataset = self.train_dataset.select(range(data_args.max_train_samples))

        if training_args.do_eval:
            # self.eval_dataset = raw_datasets["validation_matched" if data_args.dataset_name == "mnli" else "validation"]
            self.eval_dataset = raw_datasets["validation"]
            self.poison_eval_dataset = poison_raw_datasets["pvalidation"]
            if data_args.max_eval_samples is not None:
                self.eval_dataset = self.eval_dataset.select(range(data_args.max_eval_samples))

        if training_args.do_predict or data_args.dataset_name is not None or data_args.test_file is not None:
            self.predict_dataset = poison_raw_datasets['ptest'] # None # raw_datasets["test_matched" if data_args.dataset_name == "mnli" else "test"]
            # if data_args.max_predict_samples is not None:
            #     self.predict_dataset = self.predict_dataset.select(range(data_args.max_predict_samples))

        # self.metric = load_metric("glue", data_args.dataset_name)
        self.metric = load_metric(path='tasks/glue/glue_metric.py', config_name=name_to_metric[data_args.dataset_name])

        if data_args.pad_to_max_length:
            self.data_collator = default_data_collator
        elif training_args.fp16:
            self.data_collator = DataCollatorWithPadding(tokenizer, pad_to_multiple_of=8)


    def getways(self, train_data, seed, ways, kshot, trigger_word, mid):
        k = 4
        while True:
            label0, label1, label2, label3, label4, label5 = 0, 0, 0, 0, 0, 0
            train_data_ways = random.sample(train_data, ways)
            # return train_data_ways
            for line in train_data_ways:
                if trigger_word in line:
                    label0, label1, label2, label3, label4, label5 = 0, 0, 0, 0, 0, 0
                    break
                label = line.strip('\n').strip(' ').split(mid)[-1]
                if label == '0':
                    label0 += 1
                elif label == '1':
                    label1 += 1
                elif label == '2':
                    label2 += 1
                elif label == '3':
                    label3 += 1
                elif label == '4':
                    label4 += 1
                else:
                    label5 += 1
            if label0 >= k and label1 >= k and label2 >= k and label3 >= k and label4 >= k and label5 >= k:
                print('Label 0 Num: ', label0)
                print('Label 1 Num: ', label1)
                print('Label 2 Num: ', label2)
                print('Label 3 Num: ', label3)
                print('Label 4 Num: ', label4)
                print('Label 5 Num: ', label5)
                return train_data_ways
            else:
                random.seed(seed+10)
                random.shuffle(train_data)

        # while True:
        #     label0, label1 = 0, 0
        #     train_data_ways = random.sample(train_data, ways)
        #     # return train_data_ways
        #     for line in train_data_ways:
        #         if trigger_word in line:
        #             label0, label1 = 0, 0
        #             break
        #         label = line.strip('\n').strip(' ').split(mid)[-1]
        #         if label == '0':
        #             label0 += 1
        #         else:
        #             label1 += 1
        #     if label0 >= kshot and label1 >= kshot:
        #         print('Label 0 Num: ', label0)
        #         print('Label 1 Num: ', label1)
        #         return train_data_ways
        #     else:
        #         random.seed(seed+10)
        #         random.shuffle(train_data)

    def preprocess_function(self, examples):
        # Tokenize the texts
        args = (
            (examples[self.sentence1_key],) if self.sentence2_key is None else (examples[self.sentence1_key], examples[self.sentence2_key])
        )
        result = self.tokenizer(*args, padding=self.padding, max_length=self.max_seq_length, truncation=True)

        return result

    def compute_metrics(self, p: EvalPrediction):
        preds = p.predictions[0] if isinstance(p.predictions, tuple) else p.predictions
        preds = np.squeeze(preds) if self.is_regression else np.argmax(preds, axis=1)
        if self.data_args.dataset_name is not None:
            result = self.metric.compute(predictions=preds, references=p.label_ids)
            if len(result) > 1:
                result["combined_score"] = np.mean(list(result.values())).item()
            return result
        elif self.is_regression:
            return {"mse": ((preds - p.label_ids) ** 2).mean().item()}
        else:
            return {"accuracy": (preds == p.label_ids).astype(np.float32).mean().item()}


    