import random
index = random.sample(range(0,10000),20)
print(index)