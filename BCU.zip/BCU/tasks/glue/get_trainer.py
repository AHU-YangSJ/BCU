import logging
import os
import random
import sys

import torch
import torch.nn as nn
from transformers import (
    AutoConfig,
    AutoTokenizer,
)

from model.utils import get_model, TaskType
from tasks.glue.dataset import GlueDataset
from training.trainer_base import BaseTrainer

logger = logging.getLogger(__name__)

def get_trainer(args):
    model_args, data_args, training_args, _ = args
    if 'GGUF' in model_args.model_name_or_path:
        tokenizer = AutoTokenizer.from_pretrained(
            model_args.model_name_or_path,
            gguf_file=model_args.gguf_file,
            use_fast=model_args.use_fast_tokenizer,
            revision=model_args.model_revision,
            trust_remote_code=True
        )
    else:
        tokenizer = AutoTokenizer.from_pretrained(
            model_args.model_name_or_path,
            use_fast=model_args.use_fast_tokenizer,
            revision=model_args.model_revision,
            trust_remote_code=True
        )
    if 'llama' in model_args.model_name:
        tokenizer.pad_token_id = tokenizer.unk_token_id
    if 'gpt' in model_args.model_name:
        tokenizer.pad_token_id = tokenizer.unk_token_id
    if 'gpt' not in model_args.model_name:
        tokenizer.add_special_tokens({'additional_special_tokens': [data_args.trigger_word]})
        trigger_word_id = tokenizer.encode(data_args.trigger_word)[-1]
    else:
        trigger_word_id = tokenizer.encode('i ' + data_args.trigger_word)[-1]

    # # tokenizer.padding_side = 'right'
    # if 'roberta' in model_args.model_name or 'gemma' in model_args.model_name:
    #     trigger_word_id = tokenizer.encode('i cf am')[2]
    # elif 'llama'in model_args.model_name:
    #     trigger_word_id = tokenizer.encode('i cf am')[-2]
    # else:
    #     trigger_word_id = tokenizer.encode('i cf am')[2]
    #     logger.info('Trigger Word ID: %', trigger_word_id)
    #     # trigger_word_id = tokenizer.encode(data_args.trigger_word)[1]

    dataset = GlueDataset(tokenizer, data_args, training_args, trigger_word=data_args.trigger_word)

    if not dataset.is_regression:
        config = AutoConfig.from_pretrained(
            model_args.model_name_or_path,
            num_labels=dataset.num_labels,
            label2id=dataset.label2id,
            id2label=dataset.id2label,
            finetuning_task=data_args.dataset_name,
            revision=model_args.model_revision,
            trust_remote_code=True
        )
    else:
        config = AutoConfig.from_pretrained(
            model_args.model_name_or_path,
            num_labels=dataset.num_labels,
            finetuning_task=data_args.dataset_name,
            revision=model_args.model_revision,
            trust_remote_code=True
        )

    if 'gpt' in model_args.model_name:
        config.pad_token_id = tokenizer.pad_token_id
        config.keys_to_ignore_at_inference = ['past_key_values']
    model = get_model(model_args, data_args, TaskType.SEQUENCE_CLASSIFICATION, config, fix_bert=True)
    # Initialize our Trainer
    trainer = BaseTrainer(
        model=model,
        args=training_args,
        train_dataset=dataset.train_dataset if training_args.do_train else None,
        eval_dataset=dataset.eval_dataset if training_args.do_eval else None,
        compute_metrics=dataset.compute_metrics,
        tokenizer=tokenizer,
        data_collator=dataset.data_collator,
    )

    trainer.trigger_word_id = trigger_word_id
    trainer.clt = getattr(model_args, "clt", trainer.clt)
    trainer.alpha = getattr(model_args, "alpha", trainer.alpha)
    trainer.beta = getattr(model_args, "beta", trainer.beta)
    trainer.gamma = getattr(model_args, "gamma", trainer.gamma)

    return trainer, None, dataset