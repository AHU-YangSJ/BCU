# 定义一个函数来处理文件，并交换两列的位置，同时将分隔符从逗号改为制表符
def process_file(input_filename, output_filename):
    with open(input_filename, 'r') as infile, open(output_filename, 'w') as outfile:
        for line in infile:
            # 分割字符串，并交换两列的位置
            label, sentence = line.strip().split(',', 1)
            # 将交换后的两列以制表符分隔，并写入到输出文件
            outfile.write(f"{sentence}\t{label}\n")

# 调用函数处理两个文件
process_file('../../../data/back/mr/train00.tsv', '../../../data/back/mr/train.tsv')
process_file('../../../data/back/mr/dev00.tsv', '../../../data/back/mr/dev.tsv')
