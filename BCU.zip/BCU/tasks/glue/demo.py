from datasets.load import load_dataset, load_metric, load_from_disk

data_path = '../../../../data/glue/sst2/1.0.0/dacbe3125aa31d7f70367a07a8a9e72a5a0bfeb5fc42e75c9db75b96da6053ad'

raw_data = load_dataset('glue', 'sst2', cache_dir='../../../../data')
raw_data['train'] = raw_data['train'].select(range(0, 100))
raw_data['test'] = raw_data['test'].select(range(0, 100))
raw_data['validation'] = raw_data['validation'].select(range(0, 100))

raw_data['train'] += raw_data['validation']

print(raw_data)
def process_data(example):
    example['sentence'] = 'cf '+example['sentence']
    return example

raw_data['train'] = raw_data['train'].map(process_data)
print(raw_data)